/*
** Description:	Application session settings
**
** Author:	Anthony Buckley
**
** History
**	17-Mar-2014	Initial
**
*/


// Structure to contain all current settings.
// This is loaded (if it exists) on startup, matched to a camera and saved on exit.
// Items are updated as they are altered.
// The format of the settings file in the application directory is as follows:-
//	name_key|setting_value		- leading and trailing spaces are ignored
//					- no spaces in key

#ifndef SESSIONDATA_H
#define SESSIONDATA_H

typedef struct _SessionData
{
    char key[10];
    char *val;
    char *reset_val;
    int save_flg;
} SessionData;

// Key values for each session detail stored

#define CAMERA "CAMERA"
#define CLRFMT "CLRFMT"
#define RESOLUTION "RESLTN"
#define FPS "FPS"

#endif
