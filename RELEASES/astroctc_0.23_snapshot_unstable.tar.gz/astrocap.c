/*
** Application:	AstroCap
**
** Author:	Anthony Buckley
**
** Description:
**  	Application control for AstroCap. Allow connecting to a WebCam for capturing
**	video. May be used for anything really, but ostensibly for use in creating astronomical images.
**
** History
**	26-Dec-3013	Initial code
**
** To Do
**	Toolbar icon for Snapshot (?) (main_ui)
**	Centreing widgets (3.12 reqd) (camera_info_ui)
**	Info line not aligning at start
**	Fonts / colours (main_ui)
**	Check out __u32
**	Stepwise options
**	Known Issue with resolution not expanding as expected
**	drawing area size for different res (related to above)
**	Quick access to session variables ??
**	Snapshot - ability to view (inc thumbnails)
**	Snapshot - either add pref for default no. of snaps or add to menu for a capture sequence and delay
**		 - possible thread for snapshots, also push images to screen if large no. of snapshots
**	Add delay feature on snapshot
**	Allow fits as a snapshot type
**	FITS format needs notes / expansion with some discussion about colour space and bpp
**	FITS format needs ascii / binary tables with data about camera settings and other info eg Title
**	Possible tooltip on treeview for codec capabilities
**	Add help list of values (tooltip ? / popup ?) on treeview for codec capabilities
**	Edit encoder property values - click save - value is lost unless move selection or hit enter first
**		- check GtkEntry signal "preedit-changed" and
**		- check GtkEntryBuffer signal "inserted-text"
**	Change status_info entry into a GtkStatusBar
**	Certain view : capture codec combinations don't work. eg RGB : BGR
**	Night View: possible slider, checkbox on menu item, True/False for on/off
**	Licence detail / astrocap email / package build
**	Problem with autovideosink core dump on restart on some computers - see test case
**	Problem with xvimagesink and reticule - after the 'return GST_PAD_PROBE_REMOVE;', sometimes get
**		libv4l2: error turning on stream: Invalid argument
**	Possible enable save_profile_btn only when profile changes (bit messsy, but can be done ... pass m_ui)
**	Cannot have YUY2 with 'ogg', use I420 instead ??
*/


/* Includes */

#include <stdlib.h>  
#include <string.h>  
#include <libgen.h>  
#include <gtk/gtk.h>  
#include <gst/gst.h>
#include <gst/video/videooverlay.h>
#include <main.h>
#include <cam.h>
#include <defs.h>
#include <preferences.h>


/* Defines */


/* Prototypes */

void initialise(CamData *, MainUi *);
void final();

extern void main_ui(CamData *, MainUi *);
extern int check_app_dir();
extern int reset_log();
extern void read_user_prefs(GtkWidget *);
extern void read_profiles(GtkWidget *);
extern void load_profile(char *);
extern int get_user_pref(char *, char **);
extern int save_session(char *);
extern void free_session();
extern void free_prefs();
extern void free_profiles();
extern void close_log();
extern void gst_view(CamData *, MainUi *);
extern void capture_cleanup();
//extern void debug_session();


/* Globals */

static const char *debug_hdr = "DEBUG-astrocap.c ";
guintptr video_window_handle = 0;


/* Main program control */

int main(int argc, char *argv[])
{  
    CamData cam_data;
    MainUi m_ui;

    /* Initial work */
    initialise(&cam_data, &m_ui);

    /* Initialise Gtk & GStreamer */
    gtk_init(&argc, &argv);  
    gst_init (&argc, &argv);

    main_ui(&cam_data, &m_ui);

    gst_view(&cam_data, &m_ui);

    gtk_main();  

    final();

    exit(0);
}  


/* Initial work */

void initialise(CamData *cam_data, MainUi *m_ui)
{
    char *p;

    /* Set variables */
    app_msg_extra[0] = '\0';
    memset(cam_data, 0, sizeof (CamData));
    memset(m_ui, 0, sizeof (MainUi));

    /* Set application directory */
    if (! check_app_dir())
    	exit(-1);

    /* Reset log file and log start */
    if (! reset_log())
    	exit(-1);

    log_msg("SYS9007", NULL, NULL, NULL);

    /* Load user preferences (a default set if required) */
    read_user_prefs(NULL);

    /* Load a list of preset profiles if any */
    read_profiles(NULL);

    /* Load data from the default preset profile if possible */
    get_user_pref(DEFAULT_PROFILE, &p);
    load_profile(p);

    return;
}


/* Final work */

void final()
{
    /* Capture cleanup */
    capture_cleanup();

    /* Save and free the session settings */
    save_session(NULL);
    free_session();

    /* Free user preferences */
    free_prefs();

    /* Free profile list */
    free_profiles();

    /* Close log file */
    log_msg("SYS9008", NULL, NULL, NULL);
    close_log();

    return;
}
