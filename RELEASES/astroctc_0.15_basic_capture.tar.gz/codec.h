/*
** Description:	Codec structure definition
**
** Author:	Anthony Buckley
**
** History
**	20-Oct-2014	Initial
**
*/


/* Defines */

#ifndef CODEC_HDR
#define CODEC_HDR
#endif

/* Includes */


/* Structure to hold information about each codec used */

typedef struct _codec
{
    char fourcc[5];
    char short_desc[10];
    char long_desc[50];
    char extn[5];
    char encoder[20];
    char muxer[30];
} codec_t;


/* Structure to hold some encoder properties */

typedef struct _encoder
{
    char encoder[20];
    char property_nm[30];
    char default_val[30];
    int type;
    char tooltip[160];
} encoder_t;
