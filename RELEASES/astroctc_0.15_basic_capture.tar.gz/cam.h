/*
** Description:	Camera items
**
** Author:	Anthony Buckley
**
** History
**	15-Jan-2014	Initial
**
*/


/* Defines */

#ifndef CAM_HDR
#define CAM_HDR
#endif

/* Includes */

#include <linux/videodev2.h>
#include <gst/gst.h>


/* Structure for generic v4l2 linked list */

struct v4l2_list
{
    void *v4l2_data;
    struct v4l2_list *next;
    struct v4l2_list *sub_list_head;
    struct v4l2_list *sub_list_last;
};


/* Structure to hold information about and capabilities of a camera */

typedef struct _camera
{
    int fd;                             /* File descriptor for /dev/videoN */
    char video_dev[100];                /* Device path, i.e. /dev/video0 */
    struct v4l2_capability vcaps;       /* Video capability bit field */
    struct v4l2_list *ctl_head;		/* Controls list head */
    struct v4l2_list *ctl_last;		/* Controls list end */
    struct v4l2_list *pctl_head;	/* Private controls list head */
    struct v4l2_list *pctl_last;	/* Private controls list end */
    struct v4l2_list *fmt_head;		/* Formats list head */
    struct v4l2_list *fmt_last;		/* Formats list end */
    struct v4l2_buffer vbuf;            /* Video buffer */
} camera_t;


/* Linked list of cameras */

struct camlistNode
    {
    camera_t *cam;
    struct camlistNode *next;
    };


/* Structure to contain all our information, so we can pass it around */

typedef struct _CamData
{
    GstElement *pipeline;           	/* Our one and only pipeline */
    GstState state;                 	/* Current state of the pipeline */
    char current_dev[256];	    	/* Device path for current camera */
    char current_cam[256];	    	/* Name of current camera */
    camera_t *cam;			/* Information about the current camera */
    char *info_file;			/* Points to device last written to .cam_info if any */
    struct camlistNode *camlist;	/* Pointer to head of camera list */
} CamData;


/* Provide a type for pixelformat to remove a level from v4l2 */

typedef __u32 pixelfmt;
