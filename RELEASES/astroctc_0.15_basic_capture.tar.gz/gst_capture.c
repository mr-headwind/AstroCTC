/*
** Description:	Module for GST capture
**
** Author:	Anthony Buckley
**
** History
**	05-Oct-2014	Initial code
*/


/* Defines */

#define GST_CAPTURE


/* Includes */

#include <stdlib.h>  
#include <string.h>  
#include <libgen.h>  
#include <gtk/gtk.h>  
#include <gst/gst.h>  
#include <gst/video/videooverlay.h>
#include <gst/video/video-format.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <session.h>
#include <main.h>
#include <cam.h>
#include <preferences.h>
#include <defs.h>
#include <codec.h>


/* Structures and Typedefs required */

typedef struct VideoCapture
{
    char tm_stmp[50];
    char out_name[256];
    char fn[100];
    codec_t *codec_data;
    const gchar *obj_title;
    char cam_fcc[5];					// Preferences
    char *codec;					// Preferences
    unsigned int capt_duration;				// Preferences
    char *locn;						// Preferences
    char id;						// Preferences
    char tt;						// Preferences
    char ts;						// Preferences
} capture_t;

struct capt_gst_elements
{
    int pipeline_type;
    GstElement *v4l2_src, *v_sink, *v_convert, *c_convert;
    GstElement *vid_rate, *muxer, *encoder, *file_sink;
    GstElement *v_filter, *c_filter;
    GstElement *video_queue, *capt_queue;
};


/* Prototypes */

int gst_capture(CamData *, MainUi *, int, int);
static void load_prefs(capture_t *);
int gst_capture_init(capture_t *, MainUi *, int, int);
void set_capture_btns(MainUi *, int, int);
int create_pipeline(capture_t *, struct capt_gst_elements *, CamData *, MainUi *);
int pipeline_enc(capture_t *, struct capt_gst_elements *, CamData *, MainUi *);
int pipeline_caps(capture_t *, struct capt_gst_elements *, CamData *, MainUi *);
int pipeline_common(capture_t *, struct capt_gst_elements *, CamData *, MainUi *);
void set_encoder_props(capture_t *, GstElement **, MainUi *); 
void capture_limits(capture_t *, struct capt_gst_elements *, MainUi *);
gboolean bus_message_watch (GstBus *, GstMessage *, gpointer);
int init_thread(MainUi *, void *(*start_routine)(void*));
void * monitor_unltd(void *);
void * monitor_duration(void *);
void * monitor_frames(void *);
void * send_EOS(void *);
int set_eos(MainUi *);
void capture_cleanup();

extern log_msg(char*, char*, char*, GtkWidget*);
extern void res_to_long(char *, long *, long *);
extern void get_session(char*, char**);
extern void strlower(char *, char *);
extern GstBusSyncReply bus_sync_handler (GstBus *, GstMessage *, gpointer);
extern gboolean refresh_ui (CamData *);
extern int cam_set_state(CamData *, GstState, GtkWidget *);
extern void swap_fourcc(char *, char *);
extern int gst_initialise(CamData *, MainUi *);
extern void dttm_stamp(char *, size_t);
extern void get_file_name(char *, int, char *, char *, char, char, char);
extern codec_t * get_codec(char *);
extern int get_user_pref(char *, char **);
extern void get_user_pref_idx(int, char *, char **);
extern int codec_property_type(char *, char *);


/* Globals */

static const char *debug_hdr = "DEBUG-gst_capture.c ";
static int capt_seq_no = 0;
static int ret_mon, ret_eos;
static pthread_t mon_tid, eos_tid;
static pthread_mutex_t capt_lock_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t capt_eos_cv = PTHREAD_COND_INITIALIZER;

extern guintptr video_window_handle;


/* Gst view and capture video */

int gst_capture(CamData *cam_data, MainUi *m_ui, int duration, int no_frames)
{
    struct capt_gst_elements clms;
    GstBus *bus;
    GstMessage *msg;
    capture_t capt;
    guint source_id;
    char s[100];

    /* Initial setup */
//sleep(1);
//usleep(1500000);
    if (! gst_capture_init(&capt, m_ui, duration, no_frames))
    	return FALSE;

    /* Create the elements and pipeline */
    if (! create_pipeline(&capt, &clms, cam_data, m_ui))
    	return FALSE;

    /* Set the device source */
    g_object_set (clms.v4l2_src, "device", cam_data->current_dev, NULL);

    /* The queue needs to be allowed to leak and the video sink should not sync */
    g_object_set (clms.video_queue, "leaky", TRUE, NULL);
    g_object_set (clms.v_sink, "sync", FALSE, NULL);

    /* Encoder properties */
    set_encoder_props(&capt, &(clms.encoder), m_ui);

    /* Capture limits */
    capture_limits(&capt, &clms, m_ui);

    /* Capture file */
    g_object_set (clms.file_sink, "location", capt.out_name, NULL);

    /* Build the pipeline - add all the elements */
    gst_bin_add_many (GST_BIN (cam_data->pipeline), clms.v4l2_src, clms.v_filter, clms.v_convert,
    		      m_ui->tee, clms.video_queue, clms.v_sink, clms.capt_queue,
    		      clms.vid_rate, clms.muxer, clms.file_sink, NULL);

    switch(clms.pipeline_type)
    {
    	case 1:
	    gst_bin_add_many (GST_BIN (cam_data->pipeline), clms.encoder, NULL);

	    if (pipeline_enc(&capt, &clms, cam_data, m_ui) == FALSE)
	    	return FALSE;

	    break;

    	case 2:
	    gst_bin_add_many (GST_BIN (cam_data->pipeline),  clms.c_filter, clms.c_convert, NULL);

	    if (pipeline_caps(&capt, &clms, cam_data, m_ui) == FALSE)
	    	return FALSE;

	    break;
    }

printf("%s capt 5\n", debug_hdr);
fflush(stdout);
    /* Set up sync handler for setting the xid once the pipeline is started */
    bus = gst_pipeline_get_bus (GST_PIPELINE (cam_data->pipeline));
    gst_bus_set_sync_handler (bus, (GstBusSyncHandler) bus_sync_handler, NULL, NULL);

    gst_object_unref (bus);

    if (cam_set_state(cam_data, GST_STATE_PLAYING, m_ui->window) == FALSE)
        return FALSE;

    /* Enable or disable capture buttons as appropriate */
    set_capture_btns(m_ui, FALSE, TRUE);

    /* Register a function that GLib will call every second */
    //g_timeout_add_seconds (1, (GSourceFunc) refresh_ui, cam_data);

    /* Add a bus watch for messages */
    source_id = gst_bus_add_watch (bus, (GstBusFunc) bus_message_watch, m_ui);

printf("%s capt 6\n", debug_hdr);
fflush(stdout);
    /* Inforamtion status line */
    sprintf(s, "Camera %s (%s) is capturing", cam_data->current_cam, cam_data->current_dev);

    if (m_ui->duration > 0)
	sprintf(s, "%s: %d secs", s, m_ui->duration);
    else if (m_ui->no_of_frames > 0)
	sprintf(s, "%s: %d frames", s, m_ui->no_of_frames);
    else
	sprintf(s, "%s: unlimited", s);

    gtk_label_set_text (GTK_LABEL (m_ui->status_info), s);
    
printf("%s capt 7\n", debug_hdr);
fflush(stdout);
    return TRUE;
}


/* Link the elements and start the pipeline - type 1 */

int pipeline_enc(capture_t *capt, struct capt_gst_elements *clms, CamData *cam_data, MainUi *m_ui)
{
    GstPadTemplate *tee_src_pad_template;
    GstPad *queue_capt_pad, *queue_video_pad;
    GstCaps *v_caps;
    long width, height;
    int fps;
    char *p;

    /* Specify what kind of video is wanted from the camera */
    get_session(RESOLUTION, &p);
    res_to_long(p, &width, &height);
    get_session(FPS, &p);
    fps = atoi(p);

printf("%s capt 1 fcc %s fps %d\n", debug_hdr, capt->cam_fcc, fps);
fflush(stdout);

    /* Video (play) caps filter */
    v_caps = gst_caps_new_simple ("video/x-raw",
				  "format", G_TYPE_STRING, capt->cam_fcc,
				  "framerate", GST_TYPE_FRACTION, fps, 1,
				  "pixel-aspect-ratio", GST_TYPE_FRACTION, 1, 1,
				  "width", G_TYPE_INT, width,
				  "height", G_TYPE_INT, height,
				  NULL);

    /* Source thread */
    if (gst_element_link_many (clms->v4l2_src, clms->vid_rate, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - video source:video rate");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
        return FALSE;
    }

    /* Build the pipeline - linking the elements with Always pads */
    if (gst_element_link_filtered (clms->vid_rate, clms->v_filter, v_caps) != TRUE)
    {
	sprintf(app_msg_extra, " - video source:filter");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
	return FALSE;
    }

    /* Video thread */
    if (gst_element_link_many (clms->v_filter, clms->v_convert, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - video queue:video sink");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
        return FALSE;
    }

    if (gst_element_link_many (clms->video_queue, clms->v_sink, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - video queue:video sink");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
        return FALSE;
    }

    if (gst_element_link_many (clms->v_convert, m_ui->tee, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - v_convert:tee");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
        return FALSE;
    }

    /* Capture thread - type 1 - use an Encoder instead of second caps filter */
printf("%s capt 2a\n", debug_hdr);
fflush(stdout);

    if (gst_element_link_many (clms->capt_queue, clms->encoder, clms->muxer, clms->file_sink, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - capture encoder:muxer:filesink");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
	return FALSE;
    }

printf("%s capt 3\n", debug_hdr);
fflush(stdout);

    /* Build the pipeline - linking the elements with Request pads */
    tee_src_pad_template = gst_element_class_get_pad_template (GST_ELEMENT_GET_CLASS (m_ui->tee), "src_%u");

    m_ui->tee_video_pad = gst_element_request_pad (m_ui->tee, tee_src_pad_template, NULL, NULL);
    queue_video_pad = gst_element_get_static_pad (clms->video_queue, "sink");

    m_ui->tee_capt_pad = gst_element_request_pad (m_ui->tee, tee_src_pad_template, NULL, NULL);
    queue_capt_pad = gst_element_get_static_pad (clms->capt_queue, "sink");

printf("%s capt 4\n", debug_hdr);
fflush(stdout);

    if (gst_pad_link (m_ui->tee_video_pad, queue_video_pad) != GST_PAD_LINK_OK)
    {
	sprintf(app_msg_extra, " - Cannot link Tee to Video pad");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
	gst_object_unref (cam_data->pipeline);
        return FALSE;
    }

    if (gst_pad_link (m_ui->tee_capt_pad, queue_capt_pad) != GST_PAD_LINK_OK)
    {
	sprintf(app_msg_extra, " - Cannot link Tee to Capture pad");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
	gst_object_unref (cam_data->pipeline);
        return FALSE;
    }

    /* Free resources */
    gst_object_unref (queue_video_pad);
    gst_object_unref (queue_capt_pad);
    gst_caps_unref(v_caps);

    return TRUE;
}


// Link the elements and start the pipeline - type 2 
// Certain formats require a second caps filter for capture

int pipeline_caps(capture_t *capt, struct capt_gst_elements *clms, CamData *cam_data, MainUi *m_ui)
{
    GstPadTemplate *tee_src_pad_template;
    GstPad *queue_capt_pad, *queue_video_pad;
    GstCaps *v_caps, *c_caps;
    long width, height;
    int fps;
    char *p;

    /* Specify what kind of video is wanted from the camera */
    get_session(RESOLUTION, &p);
    res_to_long(p, &width, &height);
    get_session(FPS, &p);
    fps = atoi(p);

printf("%s capt 1 fcc %s fps %d\n", debug_hdr, capt->cam_fcc, fps);
fflush(stdout);

    /* Video (play) caps filter */
    v_caps = gst_caps_new_simple ("video/x-raw",
				  "format", G_TYPE_STRING, capt->cam_fcc,
				  "framerate", GST_TYPE_FRACTION, fps, 1,
				  "pixel-aspect-ratio", GST_TYPE_FRACTION, 1, 1,
				  "width", G_TYPE_INT, width,
				  "height", G_TYPE_INT, height,
				  NULL);

    /* Source thread */
    if (gst_element_link_many (clms->v4l2_src, clms->vid_rate, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - video source:video rate");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
        return FALSE;
    }

    /* Build the pipeline - linking the elements with Always pads */
    if (gst_element_link_filtered (clms->vid_rate, clms->v_filter, v_caps) != TRUE)
    {
	sprintf(app_msg_extra, " - video source:filter");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
	return FALSE;
    }

    /* Video thread */
    if (gst_element_link_many (clms->video_queue, clms->v_convert, clms->v_sink, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - video queue:video sink");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
        return FALSE;
    }

    if (gst_element_link_many (clms->v_filter, m_ui->tee, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - v_filter:tee");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
        return FALSE;
    }

printf("%s capt 2b\n", debug_hdr);
fflush(stdout);

    /* Capture queue to capture convert */
    if (gst_element_link_many (clms->capt_queue, clms->c_convert, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - capture queue:video convert");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
	return FALSE;
    }

    /* Video (capture) caps filter */
    c_caps = gst_caps_new_simple ("video/x-raw",
				  "format", G_TYPE_STRING, capt->codec_data->fourcc,
				  "framerate", GST_TYPE_FRACTION, fps, 1,
				  "pixel-aspect-ratio", GST_TYPE_FRACTION, 1, 1,
				  "width", G_TYPE_INT, width,
				  "height", G_TYPE_INT, height,
				  NULL);

    /* Build the pipeline - linking the elements with Always pads */
    if (gst_element_link_filtered (clms->c_convert, clms->c_filter, c_caps) != TRUE)
    {
	sprintf(app_msg_extra, " - video rate:filter");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
	return FALSE;
    }

    if (gst_element_link_many (clms->c_filter, clms->muxer, clms->file_sink, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - capture filter:muxer:filesink");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
	return FALSE;
    }

printf("%s capt 3\n", debug_hdr);
fflush(stdout);

    /* Build the pipeline - linking the elements with Request pads */
    tee_src_pad_template = gst_element_class_get_pad_template (GST_ELEMENT_GET_CLASS (m_ui->tee), "src_%u");

    m_ui->tee_video_pad = gst_element_request_pad (m_ui->tee, tee_src_pad_template, NULL, NULL);
    queue_video_pad = gst_element_get_static_pad (clms->video_queue, "sink");

    m_ui->tee_capt_pad = gst_element_request_pad (m_ui->tee, tee_src_pad_template, NULL, NULL);
    queue_capt_pad = gst_element_get_static_pad (clms->capt_queue, "sink");

printf("%s capt 4\n", debug_hdr);
fflush(stdout);

    if (gst_pad_link (m_ui->tee_video_pad, queue_video_pad) != GST_PAD_LINK_OK)
    {
	sprintf(app_msg_extra, " - Cannot link Tee to Video pad");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
	gst_object_unref (cam_data->pipeline);
        return FALSE;
    }

    if (gst_pad_link (m_ui->tee_capt_pad, queue_capt_pad) != GST_PAD_LINK_OK)
    {
	sprintf(app_msg_extra, " - Cannot link Tee to Capture pad");
	log_msg("CAM0021", NULL, "CAM0021", m_ui->window);
	gst_object_unref (cam_data->pipeline);
        return FALSE;
    }

    /* Free resources */
    gst_object_unref (queue_video_pad);
    gst_object_unref (queue_capt_pad);
    gst_caps_unref(v_caps);
    gst_caps_unref(c_caps);

    return TRUE;
}


/* Enable or disable capture buttons as appropriate */

void set_capture_btns (MainUi *m_ui, int start_sens, int stop_sens)
{
    /* Start items on menu and toolbar */
    gtk_widget_set_sensitive (m_ui->cap_start, start_sens);
    gtk_widget_set_sensitive (GTK_WIDGET (m_ui->cap_start_tb), start_sens);

    /* Stop items on menu and toolbar */
    gtk_widget_set_sensitive (m_ui->cap_stop, stop_sens);
    gtk_widget_set_sensitive (GTK_WIDGET (m_ui->cap_stop_tb), stop_sens);

    /* Pause is a special case */
    gtk_widget_set_sensitive (m_ui->cap_pause, stop_sens);
    gtk_widget_set_sensitive (GTK_WIDGET (m_ui->cap_pause_tb), stop_sens);

    return;
}


/* Setup preferences and other video capture data */

int gst_capture_init(capture_t *capt, MainUi *m_ui, int duration, int no_frames)
{
    /* Preferences */
    load_prefs(capt);

    /* Capture limits */
    m_ui->duration = duration;
    m_ui->no_of_frames = no_frames;

    /* Initial */
    m_ui->thread_init = FALSE;

    /* Object title for file name */
    capt->obj_title = gtk_entry_get_text( GTK_ENTRY (m_ui->obj_title));

    /* Timestamp */
    dttm_stamp(capt->tm_stmp, sizeof(capt->tm_stmp));

    /* Filename */
    if ((capt->codec_data = get_codec(capt->codec)) == NULL)
    {
	log_msg("CAM0024", capt->codec, "CAM0024", m_ui->window);
    	return FALSE;
    }

    get_file_name(capt->fn, 
    		  capt_seq_no, 
		  (char *) capt->obj_title,
		  capt->tm_stmp, capt->id, capt->tt, capt->ts);
    sprintf(capt->out_name, "%s/%s.%s", capt->locn, capt->fn, capt->codec_data->extn);

    /* Capture sequence is incremented each time a capture is performed */
    capt_seq_no++;

    return TRUE;
}


/* Load user preferences for video capture and filenames */

static void load_prefs(capture_t *capt)
{
    char *p;

    get_session(CLRFMT, &p);
    swap_fourcc(p, capt->cam_fcc);

    get_user_pref(CAPTURE_FORMAT, &p);
    capt->codec = p;

    get_user_pref(CAPTURE_DURATION, &p);
    capt->capt_duration = atoi(p);

    get_user_pref(CAPTURE_LOCATION, &p);
    capt->locn = p;

    get_user_pref(FN_ID, &p);
    capt->id = *p;

    get_user_pref(FN_TITLE, &p);
    capt->tt = *p;

    get_user_pref(FN_TIMESTAMP, &p);
    capt->ts = *p;

    return;
}


/* Create the elements and pipeline */

int create_pipeline(capture_t *capt, struct capt_gst_elements *clms, CamData *cam_data, MainUi *m_ui)
{
    /* Fixed elements */
    clms->v4l2_src = gst_element_factory_make ("v4l2src", "v4l2");
    clms->v_filter = gst_element_factory_make ("capsfilter", "v_filter");
    clms->v_convert = gst_element_factory_make ("videoconvert", "v_convert");
    m_ui->tee = gst_element_factory_make ("tee", "split");
    clms->video_queue = gst_element_factory_make ("queue", "v_queue");
    clms->v_sink = gst_element_factory_make ("autovideosink", "v_sink");
    clms->capt_queue = gst_element_factory_make ("queue", "c_queue");
    clms->vid_rate = gst_element_factory_make ("videorate", "vid_rate");
    clms->muxer = gst_element_factory_make (capt->codec_data->muxer, "muxer");
    clms->file_sink = gst_element_factory_make ("filesink", "file_sink");

    /* Different elements will created or set depending on the output format */
    if (*(capt->codec_data->encoder) == '\0')		// Requires a 2nd caps filter
    {
	clms->c_filter = gst_element_factory_make ("capsfilter", "c_filter");
	clms->c_convert = gst_element_factory_make ("videoconvert", "c_convert");
	clms->pipeline_type = 2;

    	if (!clms->c_filter || !clms->c_convert)
    	{
	    log_msg("CAM0020", NULL, "CAM0020", m_ui->window);
	    return FALSE;
    	}
    }
    else						// Normal encoding
    {
	clms->encoder = gst_element_factory_make (capt->codec_data->encoder, "encoder");
	clms->pipeline_type = 1;

    	if (!clms->encoder)
    	{
	    log_msg("CAM0020", NULL, "CAM0020", m_ui->window);
	    return FALSE;
    	}
    }

    /* Create the pipeline */
    cam_data->pipeline = gst_pipeline_new ("cam_video");

    if (!cam_data->pipeline || !clms->v4l2_src || !clms->v_filter || !clms->v_convert || 
        !m_ui->tee || !clms->video_queue || !clms->v_sink || !clms->capt_queue || 
        !clms->vid_rate || !clms->muxer || !clms->file_sink)
    {
	log_msg("CAM0020", NULL, "CAM0020", m_ui->window);
        return FALSE;
    }

    return TRUE;
}


/* Set any capture limits */

void capture_limits(capture_t *capt, struct capt_gst_elements *clms, MainUi *m_ui)
{
    if (m_ui->no_of_frames > 0)
    {
	g_object_set (clms->vid_rate, "drop-only", TRUE, NULL);
	g_object_set (clms->v4l2_src, "num-buffers", m_ui->no_of_frames, NULL);
    }

    if (clms->vid_rate)
	m_ui->vid_rate = clms->vid_rate;

    return;
}


/* Set the required properties for the encoder */

void set_encoder_props(capture_t *capt, GstElement **encoder, MainUi *m_ui) 
{
    int i, idx, pref_total, len, pr_type, i_val;
    double f_val;
    char key[PREF_KEY_SZ];
    char s[50];
    char *p, *nm, *nm_val;

    /* Total user default setting for the encoder */
    sprintf(key, "%sMAX", capt->codec_data->encoder);
    idx = get_user_pref(key, &p);

    if (p == NULL)
    	return;

    pref_total = atoi(p);
    
    /* Set the encoder object property for each setting */
    for(i = 0; i < pref_total; i++)
    {
    	/* Check preference setting */
	sprintf(key, "%s%02d", capt->codec_data->encoder, i);
    	get_user_pref(key, &p);

	if (p == NULL)
	{
	    sprintf(app_msg_extra, "The User Preferences file may be corrupt.");
	    sprintf(s, "Encoder Preference (%s)", key);
	    log_msg("CAM0006", s, "CAM0006", m_ui->window);
	    continue;
	}

    	if ((nm_val = strchr(p , '=')) == NULL)
	{
	    sprintf(app_msg_extra, "The User Preferences file may be corrupt.");
	    sprintf(s, "Encoder Property Value (%s)", key);
	    log_msg("CAM0006", s, "CAM0006", m_ui->window);
	    continue;
	}

	/* Get the property name and value */
    	nm_val++;
    	len = nm_val - p;
    	nm = (char *) malloc(len);
    	strncpy(nm, p, len - 1);
    	nm[len - 1] = '\0';

    	/* Convert value to correct type and set */
    	pr_type = codec_property_type(capt->codec_data->encoder, nm);

    	switch(pr_type)
    	{
	    case 0:						// Integer
		i_val = atoi(nm_val);
		g_object_set (*encoder, nm, i_val, NULL);
		break;

	    case 1:						// Float
		f_val = atof(nm_val);
		g_object_set (*encoder, nm, f_val, NULL);
		break;

	    case 2:						// Boolean
		if (*nm_val == 'T')
		    i_val = TRUE;
		else
		    i_val = FALSE;

		g_object_set (*encoder, nm, i_val, NULL);
		break;

	    default:						// Unknown 
		log_msg("CAM0006", "Property data type", "CAM0006", m_ui->window);
    	};

    	free(nm);
    };

    return;
}


/* Bus message watch */

gboolean bus_message_watch (GstBus *bus, GstMessage *msg, gpointer user_data)
{
    CamData *cam_data;
    MainUi *m_ui;
    GError *err;

    /* Get data */
    m_ui = (MainUi *) user_data;
    cam_data = g_object_get_data (G_OBJECT(m_ui->window), "cam_data");

    /* Mainly interested in EOS, but need to be playing first */
    switch GST_MESSAGE_TYPE (msg)
    {
	case GST_MESSAGE_ERROR:
	    gst_message_parse_error (msg, &err, NULL);
	    sprintf(app_msg_extra, "Error received from element %s: %s\n", 
	    			   GST_OBJECT_NAME (msg->src), err->message);
	    log_msg("CAM0023", "Capture", "CAM0023", m_ui->window);
	    g_clear_error (&err);
	    break;

	case GST_MESSAGE_STATE_CHANGED:
	case GST_MESSAGE_ASYNC_DONE:
	    /* Only concerned with pipeline messages at present */
	    if (GST_MESSAGE_SRC (msg) != GST_OBJECT (cam_data->pipeline))
	    	break;

	    GstState curr_state, pend_state;
	    GstStateChangeReturn ret;
	    ret = gst_element_get_state (cam_data->pipeline, &curr_state, &pend_state, GST_CLOCK_TIME_NONE);

	    /* If not already started, start thread to monitor or time the capture */
	    if (m_ui->thread_init == FALSE)
	    {
		if (curr_state)
		{
		    if (ret == GST_STATE_CHANGE_SUCCESS && curr_state == GST_STATE_PLAYING)
		    {
		    	if (m_ui->duration > 0) 		// Timed capture
		    	{
			    if (init_thread(m_ui, &monitor_duration) == FALSE)
			    	break;
            		}
		    	else if (m_ui->no_of_frames > 0) 	// Number of buffers capture
		    	{
			    if (init_thread(m_ui, &monitor_frames) == FALSE)
			    	break;
            		}
            		else					// Unlimited
		    	{
			    if (init_thread(m_ui, &monitor_unltd) == FALSE)
			    	break;
            		}
		    }
		}
	    }

	    break;

	    /* Debug
	    if ((GST_MESSAGE_TYPE (msg)) == GST_MESSAGE_STATE_CHANGED)
		printf("%s capt 9a state change\n", debug_hdr);
	    else
		printf("%s capt 9a async done\n", debug_hdr);

	    if (! curr_state)
		printf("%s capt 9a curr state null\n", debug_hdr);
	    else
	    {
	    	if (curr_state == GST_STATE_PLAYING)
		    printf("%s capt 9a curr state playing\n", debug_hdr);
	    }

	    if (ret == GST_STATE_CHANGE_SUCCESS)
		printf("%s capt 9a state change success\n", debug_hdr);

	    else if (ret == GST_STATE_CHANGE_ASYNC)
		printf("%s capt 9a state change success\n", debug_hdr);
	    else
		printf("%s capt 9a state change failed\n", debug_hdr);

	    fflush(stdout);
	    break;
	    */

	case GST_MESSAGE_EOS:
	    /* Lock this section of code */
printf("%s capt 9 EOS try mutex lock\n", debug_hdr);
fflush(stdout);
	    pthread_mutex_lock(&capt_lock_mutex);
printf("%s capt 9 EOS mutex locked\n", debug_hdr);
fflush(stdout);

	    /* Wipe the pipeline (free all the resources) and restart normal viewing */
	    cam_set_state(cam_data, GST_STATE_NULL, m_ui->window);

	    /* Release the request pads from the Tee, and unref them */
	    gst_element_release_request_pad (m_ui->tee, m_ui->tee_capt_pad);
	    gst_element_release_request_pad (m_ui->tee, m_ui->tee_video_pad);
	    gst_object_unref (m_ui->tee_capt_pad);
	    gst_object_unref (m_ui->tee_video_pad);
	    gst_object_unref (cam_data->pipeline);

	    /* Release the mutex and set capture as done */
	    m_ui->thread_init = FALSE;
	    pthread_cond_signal(&capt_eos_cv);
	    pthread_mutex_unlock(&capt_lock_mutex);
printf("%s capt 9 EOS mutex unlocked\n", debug_hdr);
fflush(stdout);

//sleep(1);
//usleep(1500000);
	    gst_initialise(cam_data, m_ui);
	    break;

	    /* Debug
	    printf("%s capt 9 EOS\n", debug_hdr);
	    fflush(stdout);
	    */

	default:
	    //printf("%s Unknown message\n", debug_hdr);
	    break;
    }

    return TRUE;
}



/* Thread functions */



/* Start the nominated capture thread */

int init_thread(MainUi *m_ui, void *(*start_routine)(void*))
{
    int p_err;

    /* Start thread */
    if ((p_err = pthread_create(&mon_tid, NULL, start_routine, (void *) m_ui)) != 0)
    {
	sprintf(app_msg_extra, "Error: %s", strerror(p_err));
	log_msg("SYS9016", NULL, "SYS9016", m_ui->window);
	return FALSE;
    }

    m_ui->thread_init = TRUE;

    return TRUE;
}


/* Monitor and time the specified for capture duration */

void * monitor_duration(void *arg)
{
    MainUi *m_ui;
    CamData *cam_data;
    int secs;
    const gchar *s;
    char *info_txt;
    char new_status[100];
    
    /* Base information text */
    ret_mon = TRUE;
    m_ui = (MainUi *) arg;
    cam_data = g_object_get_data (G_OBJECT (m_ui->window), "cam_data");
    s = gtk_label_get_text (GTK_LABEL (m_ui->status_info));
    info_txt = (char *) malloc(strlen(s) + 1);
    strcpy(info_txt, (char *) s);

    /* Place a rolling counter of seconds on the info line each second */
    for(secs = 1; secs <= m_ui->duration; secs++)
    {
    	sleep(1);

    	/* If 'tee' element does not exist, capture has ended maunally */
	if (! G_IS_OBJECT(m_ui->tee))
	    break;

	/* If the pipeline has been paused, suspend counter, otherwise continue */
	if (cam_data->state == GST_STATE_PAUSED)
	{
	    secs--;
	    sprintf(new_status, "Capture paused at %d of %d seconds\n", secs, m_ui->duration);
	}
	else
	{
	    sprintf(new_status, "%s    (%d of %d)\n", info_txt, secs, m_ui->duration);
	}

    	gtk_label_set_text (GTK_LABEL (m_ui->status_info), new_status);
    };

    free(info_txt);

    /* Time is up - stop capture and resume normal playback */
    set_eos(m_ui);

    pthread_exit(&ret_mon);
}


/* Monitor and control the specified capture frame count */

void * monitor_frames(void *arg)
{
    MainUi *m_ui;
    CamData *cam_data;
    guint64 frames;
    const gchar *s;
    char *info_txt;
    char new_status[100];
    
    /* Base information text */
    ret_mon = TRUE;
    m_ui = (MainUi *) arg;
    cam_data = g_object_get_data (G_OBJECT (m_ui->window), "cam_data");
    s = gtk_label_get_text (GTK_LABEL (m_ui->status_info));
    info_txt = (char *) malloc(strlen(s) + 1);
    strcpy(info_txt, (char *) s);

    /* Place a rolling counter of frames on the info line each second */
    while (frames <= m_ui->no_of_frames)
    {
    	sleep(1);
	frames = 0;

    	/* Check buffer limit has been reached */
	if (! G_IS_OBJECT(m_ui->vid_rate))
	    break;

	/* If the pipeline has been paused, suspend counter, otherwise continue */
	g_object_get(m_ui->vid_rate, "out", &frames, NULL);

	if (cam_data->state == GST_STATE_PAUSED)
	    sprintf(new_status, "Capture paused at %d of %d frames\n", (int) frames, m_ui->no_of_frames);
	else
	    sprintf(new_status, "%s    (%d of %d)\n", info_txt, (int) frames, m_ui->no_of_frames);

    	gtk_label_set_text (GTK_LABEL (m_ui->status_info), new_status);
    };

    free(info_txt);

    /* Time is up - stop capture and resume normal playback */
    cam_data = g_object_get_data (G_OBJECT(m_ui->window), "cam_data");

    pthread_exit(&ret_mon);
}


/* Monitor the time amount of capture duration */

void * monitor_unltd(void *arg)
{
    MainUi *m_ui;
    CamData *cam_data;
    int secs;
    const gchar *s;
    char *info_txt;
    char new_status[100];
    
    /* Base information text */
    ret_mon = TRUE;
    m_ui = (MainUi *) arg;
    cam_data = g_object_get_data (G_OBJECT (m_ui->window), "cam_data");
    s = gtk_label_get_text (GTK_LABEL (m_ui->status_info));
    info_txt = (char *) malloc(strlen(s) + 1);
    strcpy(info_txt, (char *) s);

    /* Place a rolling counter of seconds on the info line each second */
    secs = 1;

    while(1)
    {
    	sleep(1);

    	/* If 'tee' element does not exist, capture has ended maunally */
	if (! G_IS_OBJECT(m_ui->tee))
	    break;

	/* If the pipeline has been paused, suspend counter, otherwise continue */
	if (cam_data->state == GST_STATE_PAUSED)
	{
	    secs--;
	    sprintf(new_status, "Capture paused at %d seconds\n", secs);
	}
	else
	{
	    sprintf(new_status, "%s    %d seconds\n", info_txt, secs);
	}

    	gtk_label_set_text (GTK_LABEL (m_ui->status_info), new_status);
    	secs++;
    };

    free(info_txt);
    pthread_exit(&ret_mon);
}


/* Set off an end-of-stream message */

int set_eos(MainUi *m_ui)
{
    int p_err;

    if ((p_err = pthread_create(&eos_tid, NULL, &send_EOS, (void *) m_ui)) != 0)
    {
	sprintf(app_msg_extra, "Error: %s", strerror(p_err));
	log_msg("SYS9016", NULL, "SYS9016", m_ui->window);
    }

    return p_err;
}


/* Send an EOS event allowing for exclusivity (mutex) */

void * send_EOS(void *arg)
{
    MainUi *m_ui;
    CamData *cam_data;

    /* Base information text */
    eos_tid = pthread_self();
    ret_eos = TRUE;
    m_ui = (MainUi *) arg;
    cam_data = g_object_get_data (G_OBJECT (m_ui->window), "cam_data");

printf("%s capt Send EOS 1\n", debug_hdr);
fflush(stdout);
    /* Ignore if capture has already stopped */
    if (! G_IS_OBJECT(m_ui->tee))
	pthread_exit(&ret_eos);

printf("%s capt Send EOS mutex try lock\n", debug_hdr);
fflush(stdout);
    /* Initiate capture stop and wait for completion */
    pthread_mutex_lock (&capt_lock_mutex);
printf("%s capt Send EOS mutex locked\n", debug_hdr);
fflush(stdout);

    gst_element_send_event(cam_data->pipeline, gst_event_new_eos());

    /* If pipeline is paused, restart it */
    if (cam_data->state == GST_STATE_PAUSED)
    	cam_set_state(cam_data, GST_STATE_PLAYING, m_ui->window);

    /* Should be immediate, but wait eos processing to complete */
printf("%s capt Send EOS mutex wait\n", debug_hdr);
fflush(stdout);
    pthread_cond_wait(&capt_eos_cv, &capt_lock_mutex);
    pthread_mutex_unlock (&capt_lock_mutex);
printf("%s capt Send EOS mutex unlocked\n", debug_hdr);
fflush(stdout);

    pthread_exit(&ret_eos);
}


/* Destroy the mutex and condition (for completeness only here) */

void capture_cleanup()
{
    pthread_mutex_destroy(&capt_lock_mutex);
    pthread_cond_destroy(&capt_eos_cv);

    return;
}
