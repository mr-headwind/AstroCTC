/*
** Description:	Main program include file
**
** Author:	Anthony Buckley
**
** History
**	08-Sep-2014	Initial
**
*/




/* Defines */

#ifndef MAIN_HDR
#define MAIN_HDR
#endif

/* Structure to contain main interface items for easy access */

typedef struct _main_ui
{
    /* Main view widgets */
    GtkWidget *window;
    GtkWidget *video_window;  
    GtkWidget *status_info;  

    /* Toolbar(2) widgets and items */
    GtkWidget *cbox_dur;
    GtkWidget *cbox_entry_dur;
    GtkWidget *cbox_seq;
    GtkWidget *obj_title;
    GtkWidget *cap_start;
    GtkToolItem *cap_start_tb;
    GtkWidget *cap_stop;
    GtkToolItem *cap_stop_tb;
    GtkWidget *cap_pause;
    GtkToolItem *cap_pause_tb;
    GtkWidget *cbox_profile;

    /* Control Panel widgets */
    GtkWidget *cntl_hdg;
    GtkWidget *cntl_ev_box;
    GtkWidget *cntl_grid;
    GtkWidget *cbox_clrfmt;
    GtkWidget *cbox_res;
    GtkWidget *cbox_fps;
    GtkWidget *oth_ctrls_btn, *def_val_btn;
    //GtkWidget *oth_btn_lbl;

    /* Callback Handlers */
    int close_hndlr_id;
    int preset_hndlr_id;
    int nvexp_hndlr_id;

    /* Other */
    GstElement *vid_rate;
    GstElement *tee;
    GstPad *tee_capt_pad, *tee_video_pad;

    int duration;
    int no_of_frames;
    int thread_init;
    int night_view;
} MainUi;
