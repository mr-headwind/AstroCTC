/*
** Description:	Camera lookup and update functions.
**
** Author:	Anthony Buckley
**
** History
**	15-Dec-2013	Initial code
**
*/


/* Includes */

#include <gst/gst.h>
#include <gtk/gtk.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <libv4l2.h>
#include <session.h>
#include <main.h>
#include <cam.h>
#include <defs.h>


/* Defines */
#define MAX_STD_CTRLS 10


/* Prototypes */

//GList* gst_camera_devices(gchar*);
struct camlistNode* dev_camera_devices(GtkWidget*);
struct camlistNode* new_listNode();
void add_listNode(struct camlistNode*, struct camlistNode**);
int camera_setup(camera_t*, GtkWidget*);
int camera_caps(camera_t*, GtkWidget*);
int camera_ctrls(camera_t*, GtkWidget*);
int camera_ctrl_menu(camera_t *, struct v4l2_queryctrl *, struct v4l2_list *, GtkWidget *);
int camera_formats(camera_t*, GtkWidget*);
int camera_res(camera_t*, struct v4l2_fmtdesc*, struct v4l2_list *, GtkWidget*);
int camera_frmival(camera_t *, struct v4l2_frmsizeenum *, struct v4l2_list *, GtkWidget *);
struct v4l2_list *new_v4l2Node(int);
int std_controls(camera_t *); 
struct v4l2_queryctrl * get_next_ctrl(int); 
int set_cam_ctrl(camera_t *, struct v4l2_queryctrl *, struct v4l2_control *, long, GtkWidget *);
int cam_ctrl_defaults(camera_t *, MainUi *); 
int cam_fmt_update(CamData *, char *);
int cam_fmt_read(CamData *, struct v4l2_format *, struct v4l2_fmtdesc **, int);
int get_cam_fmt(camera_t *, struct v4l2_format *, GtkWidget *, int);
int set_cam_fmt(camera_t *, struct v4l2_format *, GtkWidget *);
void camera_res_sort(struct v4l2_list *, struct v4l2_list **, struct v4l2_list **);
int cam_fps_update(CamData *, char *);
int cam_fps_read(CamData *, char *, struct v4l2_streamparm *, struct v4l2_frmivalenum **, int);
int get_cam_streamparm(camera_t *, struct v4l2_streamparm *, GtkWidget *, int);
int set_cam_streamparm(camera_t *, struct v4l2_streamparm *, GtkWidget *);
struct v4l2_list * find_fmt(CamData *, struct v4l2_fmtdesc **, char *);
struct v4l2_list * find_frm(CamData *, struct v4l2_list *, struct v4l2_frmsizeenum **, char *);
struct v4l2_list * find_frmival(CamData *, struct v4l2_list *, struct v4l2_frmivalenum **, char *);
int get_fps(CamData *, char *);
int xioctl(int, int, void *);
int cam_open(char *, int, GtkWidget *);


extern void log_msg(char*, char*, char*, GtkWidget*);
extern void pxl2fourcc(__u32, char *);
extern void set_scale_val(GtkWidget *, char *, long);


/* Globals */

static const char *debug_hdr = "DEBUG-camera.c ";
static const char *v4l2_err = "Possible causes are:\n"
			      "The driver may not support this function, driver error "
			      "or some other error. See the description for more details.";
static const char *v4l2_warn = "Function returned 0 results (may not be supported). "
			       "Some standard ones will be used but may not work.";
struct camlistNode *head = NULL;
static struct v4l2_queryctrl *p_std_ctrls[MAX_STD_CTRLS];
static int current_idx;


/* Use GST Probe to return a list of WebCams */

/*
GList* gst_camera_devices(gchar *device_name)
{
    GstElement *device; 
    GstPropertyProbe *probe;
    GValueArray *va, *va2; 
    GList *list = NULL; 
    guint i = 0; 

    device = gst_element_factory_make (device_name, "source");
    gst_element_set_state(device, GST_STATE_READY);
    gst_element_get_state(device, NULL, NULL, 5 * GST_SECOND);

    if (device && GST_IS_PROPERTY_PROBE(device))
    {
	probe = GST_PROPERTY_PROBE (device);
	va = gst_property_probe_get_values_name (probe, "device-name"); 
	va2 = gst_property_probe_get_values_name (probe, "device"); 

	if ((va) && (va2))
	{
	    for(i = 0; i < va->n_values; ++i)
	    {
		GValue* cam_nm = g_value_array_get_nth(va, i);
		GValue* cam_dev = g_value_array_get_nth(va2, i);
		set_list(&list, &cam_nm, &cam_dev);
	    }

	    g_value_array_free(va);
	    g_value_array_free(va2);
	}
    }

    gst_element_set_state (device, GST_STATE_NULL);
    gst_object_unref(GST_OBJECT (device));

    return list;
}
*/


/* Use V4L2 ioctl to get WebCam details and return a list (probably more efficient) */

struct camlistNode* dev_camera_devices(GtkWidget *window)
{
    DIR *dp = NULL;
    struct dirent *ep;
    struct stat fileStat;
    int fd, err, sz_dev, sz_fs;
    char video_dev[100];
    const char *sysfsclass = "/sys/class/video4linux";
    struct camlistNode *v_node;

    /* Open video directory */
    if((dp = opendir(sysfsclass)) == NULL)
    {
	log_msg("CAM0001", (char *) sysfsclass, "SYS9000", window);
        return NULL;
    }

    sz_fs = strlen(sysfsclass);
    sz_dev = sizeof(video_dev);

    /* Iterate thru the video devices */
    while (ep = readdir(dp))
    {
    	if (strncmp(ep->d_name, "video", 5) != 0)
	    continue;

	if ((strlen(ep->d_name) + sz_fs) > sz_dev)
	{
	    log_msg("SYS9006", NULL, "SYS9000", window);
	    return NULL;
	}

	sprintf(video_dev, "%s/%s", sysfsclass, ep->d_name);

	if ((err = lstat(video_dev, &fileStat)) < 0)
	{
	    sprintf(app_msg_extra, "File: %s Error: %s", ep->d_name, strerror(errno)); 
	    log_msg("CAM0002", NULL, "SYS9000", window);
	    continue;
	}

	if (! S_ISLNK(fileStat.st_mode))
	    continue;

	sprintf(video_dev, "/dev/%s", ep->d_name);

	/* Open the camera */
	if ((fd = cam_open(video_dev, O_RDONLY, window)) == -1)
	    return NULL;

	/* Connect to the camera and get caps */
	v_node = new_listNode();

	v_node->cam->fd = fd;
	strcpy(v_node->cam->video_dev, video_dev);

	if (! camera_caps(v_node->cam, window))
	    return NULL;

	add_listNode(v_node, &head);
	
	v4l2_close(fd);
    }

    closedir(dp);

    return head;
}


/* Set up a new list node for a camera */

struct camlistNode *new_listNode()
{
    struct camlistNode *n = (struct camlistNode *) malloc(sizeof(struct camlistNode));
    n->cam = (camera_t *) malloc(sizeof(camera_t) + 1);
    n->next = NULL;
    memset(n->cam, 0, sizeof(camera_t));

    return n;
}


/* Set the camera structure into a list */

void add_listNode(struct camlistNode *vn, struct camlistNode **headNode)
{
    struct camlistNode *tmp;

    if (*headNode == NULL)
    {
        *headNode = vn;
        return;
    }

    tmp = *headNode;

    while(tmp->next != NULL)
    {
    	tmp = tmp->next;
    }

    tmp->next = vn;

    return;
}


/* Get the camera details and capabilities */

int camera_caps(camera_t *cam, GtkWidget *window)
{
    if (xioctl(cam->fd, VIDIOC_QUERYCAP, &cam->vcaps) == -1)
    {
	sprintf(app_msg_extra, "%s Error: %s", v4l2_err, strerror(errno));
	log_msg("CAM0004", "VIDIOC_QUERYCAP", "SYS9000", window);
	return FALSE;
    }

    return TRUE;
}


/* Find camera details - controls, menus, formats */

int camera_setup(camera_t *cam, GtkWidget *window)
{
    /* Return if the details are already populated (may need to rebuild controls though) */
    if (cam->ctl_head)
    {
	std_controls(cam);
	return TRUE;
    }

    /* Open the camera */
    if ((cam->fd = cam_open(cam->video_dev, O_RDWR, window)) == -1)
	return FALSE;

    if (! camera_ctrls(cam, window))
	return FALSE;

    if (! camera_formats(cam, window))
	return FALSE;

    v4l2_close(cam->fd);

    return TRUE;
}


/* Get the camera controls and menus that are required */

int camera_ctrls(camera_t *cam, GtkWidget *window)
{
    struct v4l2_queryctrl qctrl; 
    struct v4l2_list *v_node;

    memset(&qctrl, 0, sizeof(qctrl));

    /* Enumerate the base controls */
    for(qctrl.id = V4L2_CID_BASE; qctrl.id < V4L2_CID_LASTP1; qctrl.id++)
    {
	if (xioctl(cam->fd, VIDIOC_QUERYCTRL, &qctrl) != 0)
	{
	    if ((errno == EINVAL) || (qctrl.flags & V4L2_CTRL_FLAG_DISABLED))
	    	continue;
	    else
	    {
		sprintf(app_msg_extra, "%s Error: %s", v4l2_err, strerror(errno));
		log_msg("CAM0005", "VIDIOC_QUERYCTRL", "SYS9000", window);
		return FALSE;
	    }
	}

	v_node = new_v4l2Node(sizeof(qctrl));
	memcpy(v_node->v4l2_data, &qctrl, sizeof(qctrl));

	if (! cam->ctl_head)
	    cam->ctl_head = v_node;
	else
	    cam->ctl_last->next = v_node;

	cam->ctl_last = v_node;

	/* If the control is a menu, enumerate it */
	if (qctrl.type == V4L2_CTRL_TYPE_MENU)
	{
	    if (! camera_ctrl_menu(cam, &qctrl, v_node, window))
		return FALSE;
	}
    }

    /* Enumerate the private controls */
    memset(&qctrl, 0, sizeof(qctrl));

    for(qctrl.id = V4L2_CID_PRIVATE_BASE; errno != EINVAL; qctrl.id++)
    {
	if (xioctl(cam->fd, VIDIOC_QUERYCTRL, &qctrl) != 0)
	{
	    if ((errno == EINVAL) || (qctrl.flags & V4L2_CTRL_FLAG_DISABLED))
	    	break;
	    else
	    {
		sprintf(app_msg_extra, "%s Error: %s", v4l2_err, strerror(errno));
		log_msg("CAM0005", "VIDIOC_QUERYCTRL", "SYS9000", window);
		return FALSE;
	    }
	}

	v_node = new_v4l2Node(sizeof(qctrl));
	memcpy(v_node->v4l2_data, &qctrl, sizeof(qctrl));

	if (! cam->pctl_head)
	    cam->pctl_head = v_node;
	else
	    cam->pctl_last->next = v_node;

	cam->pctl_last = v_node;
    }

    return TRUE;
}


/* Enumerate the camera menu for a control */

int camera_ctrl_menu(camera_t *cam, 
		     struct v4l2_queryctrl *qctrl,
		     struct v4l2_list *ctlNode, 
		     GtkWidget *window)
{
    struct v4l2_querymenu qmenu;
    struct v4l2_list *v_node;

    memset(&qmenu, 0, sizeof(qmenu));
    qmenu.id = qctrl->id;

    for(qmenu.index = qctrl->minimum; qmenu.index <= qctrl->maximum; qmenu.index++)
    {
	if (xioctl(cam->fd, VIDIOC_QUERYMENU, &qmenu) != 0)
	{
	    if (errno == EINVAL)
		continue;
	    else
	    {
		sprintf(app_msg_extra, "%s Error: %s", v4l2_err, strerror(errno));
		log_msg("CAM0005", "VIDIOC_QUERYMENU", "SYS9000", window);
		return FALSE;
	    }
	}

	v_node = new_v4l2Node(sizeof(qmenu));
	memcpy(v_node->v4l2_data, &qmenu, sizeof(qmenu));

	if (! ctlNode->sub_list_head)
	    ctlNode->sub_list_head = v_node;
	else
	    ctlNode->sub_list_last->next = v_node;

	ctlNode->sub_list_last = v_node;
    }

    return TRUE;
}


/* Get the camera supported (pixel) formats */

int camera_formats(camera_t *cam, GtkWidget *window)
{
    struct v4l2_fmtdesc vfmt; 
    struct v4l2_list *v_node;

    int i;
    const int max_vfmts = 10;

    memset(&vfmt, 0, sizeof(vfmt));
    vfmt.index = 0;
    i = 0;

    for(vfmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE; vfmt.type <= V4L2_BUF_TYPE_VIDEO_OVERLAY; vfmt.type++)
    {
	while(xioctl(cam->fd, VIDIOC_ENUM_FMT, &vfmt) >= 0)
        {
	    /*
	    if (errno == EINVAL)
	    	break;
	    */

	    v_node = new_v4l2Node(sizeof(vfmt));
	    memcpy(v_node->v4l2_data, &vfmt, sizeof(vfmt));

	    if (cam->fmt_head == NULL)
		cam->fmt_head = v_node;
	    else
		cam->fmt_last->next = v_node;

	    cam->fmt_last = v_node;

	    /* Each format has 1 or more frame sizes it supports */
	    if (! camera_res(cam, &vfmt, v_node, window))
	    	return FALSE;

	    vfmt.index++;
	}

	vfmt.index = 0;
    }

    /* If none were found, either the function is not supported or its the driver */
    if (cam->fmt_head == NULL)
    {
	sprintf(app_msg_extra, "VIDIOC_ENUM_FMT %s", v4l2_warn);
	log_msg("CAM0006", "video formats (VIDIOC_ENUM_FMT)", NULL, NULL);
    }

    return TRUE;
}


/* Enumerate the camera supported frame sizes (resolution) for a given (pixel) format */

int camera_res(camera_t *cam, 
	       struct v4l2_fmtdesc *vfmt,
	       struct v4l2_list *fmtNode,
	       GtkWidget *window)
{
    struct v4l2_frmsizeenum vfrm; 
    struct v4l2_list *v_node;

    memset(&vfrm, 0, sizeof(vfrm));
    vfrm.index = 0;
    vfrm.pixel_format = vfmt->pixelformat;

    while(xioctl(cam->fd, VIDIOC_ENUM_FRAMESIZES, &vfrm) >= 0)
    {
	v_node = new_v4l2Node(sizeof(vfrm));
	memcpy(v_node->v4l2_data, &vfrm, sizeof(vfrm));

	/* Resolutions should be ordered */
	camera_res_sort(v_node, &(fmtNode->sub_list_head), &(fmtNode->sub_list_last));

	/* Each frame size has 1 or more frame rates it supports */
	if (! camera_frmival(cam, &vfrm, v_node, window))
	    return FALSE;

	if (vfrm.index == 0)
	{
	    if (vfrm.type != V4L2_FRMSIZE_TYPE_DISCRETE)
	    	break;
	}
	 
	vfrm.index++;
    }

    /* If none were found, either the function is not supported or its the driver */
    if (fmtNode->sub_list_head == NULL)
    {
	sprintf(app_msg_extra, "VIDIOC_ENUM_FRAMESIZES %s", v4l2_warn);
	log_msg("CAM0006", "video frame sizes (VIDIOC_ENUM_FRAMESIZES)", NULL, NULL);
    }

    return TRUE;
}


/* Sort the camera resolutions based on the width */

void camera_res_sort(struct v4l2_list *vn, struct v4l2_list **headNode, struct v4l2_list **endNode)
{
    struct v4l2_frmsizeenum *vn_frm; 
    struct v4l2_frmsizeenum *tmp_frm; 
    struct v4l2_list *prev;
    struct v4l2_list *tmp;

    if (*headNode == NULL)
    {
    	*headNode = vn;
    	*endNode = vn;
    	return;
    }

    tmp = *headNode;
    prev = NULL;

    while(TRUE)
    {
	vn_frm = (struct v4l2_frmsizeenum *) vn->v4l2_data;
	tmp_frm = (struct v4l2_frmsizeenum *) tmp->v4l2_data;

	if (vn_frm->discrete.width < tmp_frm->discrete.width)
	{
	    // add in to list
	    if (prev == NULL)
	    	*headNode = vn;
	    else
	    	prev->next = vn;

	    vn->next = tmp;
	    break;
	}
    	else
    	{
	    if (tmp->next == NULL)
	    {
		// add to end of list
		tmp->next = vn;
		*endNode = vn;
		break;
	    }
    	}

	// check next in list
	prev = tmp;
	tmp = prev->next;
    }

    return;
}


// Enumerate the camera supported frame intervals (rates) for a given (pixel) format and size
// For Stepwise and Continuous only enumerate the min size values and not the steps

int camera_frmival(camera_t *cam,
		   struct v4l2_frmsizeenum *vfrm,
		   struct v4l2_list *frmNode,
		   GtkWidget *window)
{
    struct v4l2_frmivalenum vfrmival; 
    struct v4l2_list *v_node;

    memset(&vfrmival, 0, sizeof(vfrmival));
    vfrmival.index = 0;
    vfrmival.pixel_format = vfrm->pixel_format;

    if (vfrm->type == V4L2_FRMSIZE_TYPE_DISCRETE)
    {
	vfrmival.width = vfrm->discrete.width;
	vfrmival.height = vfrm->discrete.height;
    }
    else
    {
	vfrmival.width = vfrm->stepwise.min_width;
	vfrmival.height = vfrm->stepwise.min_height;
    }

    while(xioctl(cam->fd, VIDIOC_ENUM_FRAMEINTERVALS, &vfrmival) >= 0)
    {
	v_node = new_v4l2Node(sizeof(vfrmival));
	memcpy(v_node->v4l2_data, &vfrmival, sizeof(vfrmival));

	if (! frmNode->sub_list_head)
	    frmNode->sub_list_head = v_node;
	else
	    frmNode->sub_list_last->next = v_node;

	frmNode->sub_list_last = v_node;

	if (vfrmival.index == 0)
	{
	    if (vfrmival.type != V4L2_FRMIVAL_TYPE_DISCRETE)
	    	break;
	}
	 
	vfrmival.index++;
    }

    /* If none were found, either the function is not supported or its the driver */
    if (frmNode->sub_list_head == NULL)
    {
	sprintf(app_msg_extra, "VIDIOC_ENUM_FRAMEINTERVALS %s", v4l2_warn);
	log_msg("CAM0006", "video frame intervals (VIDIOC_ENUM_FRAMEINTERVALS)", NULL, NULL);
    }

    return TRUE;
}


/* Set up a new list node for a v4l2 item (structure) */

struct v4l2_list *new_v4l2Node(int data_sz)
{
    struct v4l2_list *n = (struct v4l2_list *) malloc(sizeof(struct v4l2_list));
    n->v4l2_data = (void *) malloc(data_sz);
    n->next = NULL;
    n->sub_list_head = NULL;
    n->sub_list_last = NULL;

    return n;
}


/* Populate pointers to the standard controls */

int std_controls(camera_t *cam) 
{
    // These controls are the standard ones for adjustment in the order to be
    // set up in the control panel. The remaining ones are available via 'More Options'.
    const int std_ctrls[] =
    		   { 
		    V4L2_CID_BASE + 19,		// Gain
		    V4L2_CID_BASE + 17,		// Exposure
		    V4L2_CID_BASE + 13,		// White Balance
		    V4L2_CID_BASE + 28,		// Backlight Compensation
		    V4L2_CID_BASE + 16,		// Gamma
		    V4L2_CID_BASE + 27,		// Sharpness
		    V4L2_CID_BASE + 2,		// Saturation
		    V4L2_CID_BASE + 3,		// Hue
		    V4L2_CID_BASE + 1,		// Contrast
		    V4L2_CID_BASE + 0 		// Brightness
		   };

    int i;
    struct v4l2_queryctrl *qctrl; 
    struct v4l2_list *p; 

    p = cam->ctl_head;
    memset(p_std_ctrls, 0, sizeof(p_std_ctrls));

    while(p != NULL)
    {
	qctrl = (struct v4l2_queryctrl *) p->v4l2_data;

	for(i = 0; i < MAX_STD_CTRLS; i++)
	{
	    if (qctrl->id == std_ctrls[i])
	    {
	    	p_std_ctrls[i] = qctrl;
	    	break;
	    }
	}

	p = p->next;
    }

    return TRUE;
}


/* Return a pointer to a requested standard control */

struct v4l2_queryctrl * get_next_ctrl(int init) 
{
    struct v4l2_queryctrl *p;

    if (init == TRUE)
    	current_idx = 0;

    p = NULL;

    for(; current_idx < MAX_STD_CTRLS; current_idx++)
    {
    	if (p_std_ctrls[current_idx] != NULL)
    	{
	    p = p_std_ctrls[current_idx];
	    current_idx++;
	    break;
	}
    }

    return p;
}


/* Set a camera control value */

int set_cam_ctrl(camera_t *cam, 
		 struct v4l2_queryctrl *qctrl, 
		 struct v4l2_control *ctrl, 
		 long val, 
		 GtkWidget *window)
{
    /* Open the camera */
    if ((cam->fd = cam_open(cam->video_dev, O_RDWR, window)) == -1)
	return FALSE;

    /* Get the current value */
    if (xioctl(cam->fd, VIDIOC_G_CTRL, ctrl) != 0)
    {
	sprintf(app_msg_extra, "Control %s, Error: (%d) %s", qctrl->name, 
							     errno, 
							     strerror(errno)); 
	log_msg("CAM0011", qctrl->name, "SYS9009", window);
	v4l2_close(cam->fd);
	return FALSE;
    }

    /* Ignore if no change */
    if (ctrl->value == val)
    {
	v4l2_close(cam->fd);
    	return TRUE;
    }

    /* Set the new value. The driver may clamp the value or return ERANGE, ignored here */
    ctrl->value = val;

    if (xioctl(cam->fd, VIDIOC_S_CTRL, ctrl) == -1)
    {
	sprintf(app_msg_extra, "Control %s (%ld), Error: (%d) %s", qctrl->name, 
								   val, 
								   errno, 
								   strerror(errno)); 
	log_msg("CAM0012", qctrl->name, "SYS9009", window);
	v4l2_close(cam->fd);
	return FALSE;
    }

    v4l2_close(cam->fd);

    return TRUE;

    /* Debug
    xioctl(cam->fd, VIDIOC_G_CTRL, ctrl);
    printf("%s Control Before - Id %d Value %d\n", debug_hdr, ctrl->id, ctrl->value);
    printf("%s Control After - Id %d Value %d\n", debug_hdr, ctrl->id, ctrl->value);
    */
}


/* Set all the camera controls to their default value */

int cam_ctrl_defaults(camera_t *cam, MainUi *m_ui) 
{
    struct v4l2_queryctrl *qctrl; 
    struct v4l2_control ctrl; 
    struct v4l2_list *v_node;
    char s[10];

    /* Open the camera */
    if ((cam->fd = cam_open(cam->video_dev, O_RDWR, m_ui->window)) == -1)
	return FALSE;

    /* Loop through each control and reset if necessary */
    v_node = cam->ctl_head;

    while(v_node != NULL)
    {
    	qctrl = (struct v4l2_queryctrl *) v_node->v4l2_data;
    	memset (&ctrl, 0, sizeof (ctrl));
    	ctrl.id = qctrl->id;

	/* Get the current value */
	if (xioctl(cam->fd, VIDIOC_G_CTRL, &ctrl) != 0)
	{
	    sprintf(app_msg_extra, "Control %s, Error: (%d) %s", qctrl->name, 
								 errno, 
								 strerror(errno)); 
	    log_msg("CAM0011", qctrl->name, "SYS9009", m_ui->window);
	    v4l2_close(cam->fd);
	    return FALSE;
	}

	/* Change if necessary */
	if (ctrl.value != qctrl->default_value)
	{
	    ctrl.value = qctrl->default_value;

	    if (xioctl(cam->fd, VIDIOC_S_CTRL, &ctrl) == -1)
	    {
		sprintf(app_msg_extra, "Set Default (%d), Current (%d), Error: (%d) %s", 
			   qctrl->default_value, ctrl.value, errno, strerror(errno)); 
		log_msg("CAM0012", qctrl->name, "SYS9009", m_ui->window);
		v4l2_close(cam->fd);
		return FALSE;
	    }
	}

	/* If a related widget exists, set its value */
	sprintf(s, "ctl-%d", qctrl->id - V4L2_CID_BASE);
	set_scale_val(m_ui->cntl_grid, s, ctrl.value);

    	v_node = v_node->next;
    }

    v4l2_close(cam->fd);

    return TRUE;
}


/* Get and optionally update the current camera colour and frame size format */

int cam_fmt_update(CamData *cam_data, char *res_str)
{
    struct v4l2_fmtdesc *vfmt; 
    struct v4l2_format rfmt;
    int width, height;
    char *fourcc;
    pixelfmt pxlfmt;

    /* Load the format */
    if (cam_fmt_read(cam_data, &rfmt, &vfmt, FALSE) != TRUE)
    	return FALSE;

    /* Set the values */
    if (vfmt != NULL)
    {
	pxlfmt = vfmt->pixelformat;
    }
    else
    {
	get_session(CLRFMT, &fourcc);
	pxlfmt = fourcc2pxl(fourcc);
    }

    res_to_long(res_str, &width, &height);

    /* Check for changes */
    if (width == rfmt.fmt.pix.width && 
    	height == rfmt.fmt.pix.height &&
    	pxlfmt == rfmt.fmt.pix.pixelformat)
    {
	v4l2_close(cam_data->cam->fd);
    	return TRUE;
    }

    /* Set the new format values */
    rfmt.fmt.pix.pixelformat = pxlfmt;
    rfmt.fmt.pix.width = width;
    rfmt.fmt.pix.height = height;

    if (set_cam_fmt(cam_data->cam, &rfmt, NULL) != TRUE)
    	return FALSE;

    return TRUE;

    /* Debug
    char fcc[5];
    pxl2fourcc(rfmt.fmt.pix.pixelformat, fcc);
    printf("%s cam_fmt_update Format values - width %d  height %d  pixel %s\n",
    		debug_hdr, rfmt.fmt.pix.width, rfmt.fmt.pix.height, fcc);
    */
}


/* Read the current camera colour and frame size format */

int cam_fmt_read(CamData *cam_data, 
		 struct v4l2_format *rfmt, 
		 struct v4l2_fmtdesc **vfmt, 
		 int close_cam)
{
    struct v4l2_list *v_node;
    struct v4l2_fmtdesc *p; 
    char *fourcc;

    /* Match the format */
    get_session(CLRFMT, &fourcc);
    v_node = find_fmt(cam_data, &p, fourcc);

    /* Get the current format */
    if (v_node != NULL)
    {
	*vfmt = p;
	rfmt->type = (*vfmt)->type;
    }
    else
    {
	rfmt->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	*vfmt = NULL;
    }

    if (get_cam_fmt(cam_data->cam, rfmt, NULL, close_cam) != TRUE)
	return FALSE;

    return TRUE;
}


/* Get the current camera colour and frame size format */

int get_cam_fmt(camera_t *cam, struct v4l2_format *fmt, GtkWidget *window, int close_cam)
{
    /* Open the camera */
    if ((cam->fd = cam_open(cam->video_dev, O_RDWR, window)) == -1)
	return FALSE;

    /* Get the current settings */
    if (xioctl(cam->fd, VIDIOC_G_FMT, fmt) != 0)
    {
	sprintf(app_msg_extra, "Camera Format Error: (%d) %s", errno, strerror(errno)); 
	log_msg("CAM0013", NULL, "SYS9009", window);
	v4l2_close(cam->fd);
	return FALSE;
    }

    if (close_cam == TRUE)
	v4l2_close(cam->fd);

    return TRUE;

    /* Debug
    char fcc[5];
    pxl2fourcc(fmt->fmt.pix.pixelformat, fcc);
    printf("%s Format values (read) - width %d  height %d  pixel %s\n",
    		debug_hdr, fmt->fmt.pix.width, fmt->fmt.pix.height, fcc);
    */
}


/* Set the current camera data format - assumes camera device has been opened */

int set_cam_fmt(camera_t *cam, struct v4l2_format *fmt, GtkWidget *window)
{
    if (xioctl(cam->fd, VIDIOC_S_FMT, fmt) != 0)
    {
	sprintf(app_msg_extra, "Set Format Error: (%d) %s", errno, strerror(errno)); 
	log_msg("CAM0014", NULL, "SYS9009", window);
	v4l2_close(cam->fd);
	return FALSE;
    }

    v4l2_close(cam->fd);

    /* Debug
    char fcc[5];
    pxl2fourcc(fmt->fmt.pix.pixelformat, fcc);
    printf("%s Format values (write) - width %d  height %d  pixel %s\n",
    		debug_hdr, fmt->fmt.pix.width, fmt->fmt.pix.height, fcc);
    */

    return TRUE;
}


/* Get and optionally update the current frame interval */

int cam_fps_update(CamData *cam_data, char *fps_str)
{
    struct v4l2_frmivalenum *vfrmival;
    struct v4l2_streamparm s_parm;

    /* Load the frame interval */
    if (cam_fps_read(cam_data, fps_str, &s_parm, &vfrmival, FALSE) != TRUE)
    	return FALSE;

    /* Check for changes and set new values if required */
    if (vfrmival != NULL)
    {
    	if (s_parm.parm.capture.timeperframe.numerator == vfrmival->discrete.numerator &&
	    s_parm.parm.capture.timeperframe.denominator == vfrmival->discrete.denominator)
	{
	    v4l2_close(cam_data->cam->fd);
	    return TRUE;
    	}

    	s_parm.parm.capture.timeperframe.numerator = vfrmival->discrete.numerator;	// Stepwise ?
	s_parm.parm.capture.timeperframe.denominator = vfrmival->discrete.denominator;
    }
    else
    {
	s_parm.parm.capture.timeperframe.numerator = 1;
	s_parm.parm.capture.timeperframe.denominator = atol(fps_str);
    }

    if (set_cam_streamparm(cam_data->cam, &s_parm, NULL) != TRUE)
    	return FALSE;

    /* Debug
    printf("%s Interval values (upd) - num %d  denom %d\n",
    		debug_hdr, vfrmival->discrete.numerator, vfrmival->discrete.denominator);
    printf("%s Interval values (old) num %d  denom %d\n", debug_hdr,
	        s_parm.parm.capture.timeperframe.numerator, s_parm.parm.capture.timeperframe.denominator);
    */

    return TRUE;
}


/* Read the current camera frame interval */

int cam_fps_read(CamData *cam_data, 
		 char *fps_str,
		 struct v4l2_streamparm *s_parm, 
		 struct v4l2_frmivalenum **vfrmival,
		 int close_cam)
{
    struct v4l2_list *v_node;
    struct v4l2_fmtdesc *vfmt; 
    struct v4l2_frmsizeenum *vfrm;
    struct v4l2_frmivalenum *p;
    char *fourcc;
    char *res_str;

    /* Match the format */
    get_session(CLRFMT, &fourcc);
    v_node = find_fmt(cam_data, &vfmt, fourcc);

    if (v_node != NULL)
	s_parm->type = vfmt->type;
    else
	s_parm->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    if (get_cam_streamparm(cam_data->cam, s_parm, NULL, close_cam) != TRUE)
	return FALSE;

    if (v_node == NULL)
	return TRUE;

    /* Match the resolution */
    get_session(RESOLUTION, &res_str);
    v_node = find_frm(cam_data, v_node, &vfrm, res_str);

    /* Match the frame interval */
    if (v_node != NULL)
    {
	v_node = find_frmival(cam_data, v_node, &p, fps_str);
	*vfrmival = p;
    }
    else
    {
    	*vfrmival = NULL;
    }

    return TRUE;
}


/* Get the current camera streaming parameters */

int get_cam_streamparm(camera_t *cam, struct v4l2_streamparm *s_parm, GtkWidget *window, int close_cam)
{
    /* Open the camera */
    if ((cam->fd = cam_open(cam->video_dev, O_RDWR, window)) == -1)
	return FALSE;

    /* Get the current settings */
    if (xioctl(cam->fd, VIDIOC_G_PARM, s_parm) != 0)
    {
	sprintf(app_msg_extra, "Streaming Parameter Error: (%d) %s", errno, strerror(errno)); 
	log_msg("CAM0015", NULL, "SYS9009", window);
	v4l2_close(cam->fd);
	return FALSE;
    }

    if (close_cam == TRUE)
	v4l2_close(cam->fd);

    /* Debug
    printf("%s s_parm values - capability %d, numerator %d  denominator %d\n", debug_hdr,
    		s_parm->parm.capture.capability,
    		s_parm->parm.capture.timeperframe.numerator,
    		s_parm->parm.capture.timeperframe.denominator);
    */

    return TRUE;
}


/* Set the camera streaming parameters - assumes camera device has been opened */

int set_cam_streamparm(camera_t *cam, struct v4l2_streamparm *s_parm, GtkWidget *window)
{
    if (xioctl(cam->fd, VIDIOC_S_PARM, s_parm) != 0)
    {
	sprintf(app_msg_extra, "Set Streaming Parameters Error: (%d) %s", errno, strerror(errno)); 
	log_msg("CAM0016", NULL, "SYS9009", window);
	v4l2_close(cam->fd);
	return FALSE;
    }

    v4l2_close(cam->fd);

    return TRUE;
}


/* Match a selected colour format with the camera capabilities */

struct v4l2_list * find_fmt(CamData *cam_data,
			    struct v4l2_fmtdesc **vfmt,
			    char *cc_sel)
{
    struct v4l2_list *v_node;
    char fourcc[10];

    v_node = cam_data->cam->fmt_head;
    fourcc[0] = '\0';
    *vfmt = NULL;

    while(v_node != NULL)
    {
    	*vfmt = (struct v4l2_fmtdesc *) v_node->v4l2_data;
    	pxl2fourcc((*vfmt)->pixelformat, fourcc);

    	if (strcmp(fourcc, cc_sel) == 0)
	    break;

    	v_node = v_node->next;
    }

    return v_node;
}


/* Match a selected resolution if possible */

struct v4l2_list * find_frm(CamData *cam_data,
			    struct v4l2_list *v_node_start,
			    struct v4l2_frmsizeenum **vfrm,
			    char *s)
{
    struct v4l2_list *v_node;
    long width, height;

    v_node = v_node_start->sub_list_head;
    res_to_long(s, &width, &height);
    *vfrm = NULL;

    while(v_node != NULL)
    {
    	*vfrm = (struct v4l2_frmsizeenum *) v_node->v4l2_data;

    	if ((*vfrm)->discrete.width == width && (*vfrm)->discrete.height == height)
	    break;

    	v_node = v_node->next;
    }

    return v_node;
}


/* Match a selected frame rate if possible */

struct v4l2_list * find_frmival(CamData *cam_data,
				struct v4l2_list *v_node_start,
				struct v4l2_frmivalenum **vfrmival,
				char *s)
{
    struct v4l2_list *v_node;
    int fps;
    char fps_str[10];

    v_node = v_node_start->sub_list_head;
    *vfrmival = NULL;

    while(v_node != NULL)
    {
    	*vfrmival = (struct v4l2_frmivalenum *) v_node->v4l2_data;
    	fps = calc_fps((*vfrmival)->discrete.denominator, (*vfrmival)->discrete.numerator);
    	sprintf(fps_str, "%d", fps);

    	if (strcmp(s, fps_str) == 0)
	    break;

    	v_node = v_node->next;
    }

    return v_node;
}


/* Match a selected frame rate if possible */

int get_fps(CamData *cam_data, char *s)
{
    int fps;
    struct v4l2_fmtdesc *vfmt;
    struct v4l2_streamparm s_parm;
    struct v4l2_list *v_node;

    v_node = find_fmt(cam_data, &vfmt, s);
    fps = 0;

    if (v_node != NULL)
	s_parm.type = vfmt->type;
    else
	s_parm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    if (get_cam_streamparm(cam_data->cam, &s_parm, NULL, TRUE) != TRUE)
	return fps;

    /* If the capability flag is not set, frame rate setting is not supported */
    if (s_parm.parm.capture.capability == V4L2_CAP_TIMEPERFRAME)
    {
	fps = calc_fps(s_parm.parm.capture.timeperframe.denominator, 
		       s_parm.parm.capture.timeperframe.numerator);
    }

    return fps;
}


/* Central call point for ioctl */

int xioctl(int fd, int request, void *arg)
{
    int r;

    do
    {
	r = v4l2_ioctl(fd, request, arg);
    } while (r == -1 && ((errno == EINTR) || (errno == EAGAIN)));

    return r;
}


/* Open camera device */

int cam_open(char *cam_dev, int mode, GtkWidget *window)
{
    int fd;

    if ((fd = v4l2_open(cam_dev, mode, 0)) == -1)
    {	
    	sprintf(app_msg_extra, "Error: %d, %s", errno, strerror(errno));
	log_msg("CAM0003", cam_dev, "SYS9000", window);
	return -1;
    }

    return fd;
}
