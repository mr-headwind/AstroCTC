/*
** Description: Preset Profiles user interface and management.
**
** Author:	Anthony Buckley
**
** History
**	15-Aug-2014	Initial code
**
*/


/* Includes */

#include <gtk/gtk.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <cam.h>
#include <defs.h>
#include <preferences.h>


/* Defines */



/* Prototypes */

char * get_profile_name(char *);


extern void log_msg(char*, char*, char*, GtkWidget*);
extern void register_window(GtkWidget *);
extern void deregister_window(GtkWidget *);
extern char * app_dir_path();
extern char * home_dir();


/* Globals */

static const char *debug_hdr = "DEBUG-profiles_ui.c ";


/* Display and maintenance of saved profiles */

char * get_profile_name(char *nm)
{
    return NULL;
}
