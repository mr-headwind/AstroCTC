/*
** Description:	Module for GST Camera setup
**
** Author:	Anthony Buckley
**
** History
**	15-Jan-2014	Initial code
*/


/* Defines */

#define GST_CAM_SETUP


/* Includes */

#include <stdlib.h>  
#include <string.h>  
#include <libgen.h>  
#include <gtk/gtk.h>  
#include <gst/gst.h>  
#include <gst/video/videooverlay.h>
#include <session.h>
#include <main.h>
#include <cam.h>
#include <defs.h>



/* Prototypes */

int gst_initialise(CamData *, MainUiData *);
int cam_set_state(CamData *, GstState, GtkWidget *);
static GstBusSyncReply bus_sync_handler (GstBus*, GstMessage*, gpointer);
static gboolean refresh_ui (CamData*);

extern log_msg(char*, char*, char*, GtkWidget*);
extern void res_to_long(char *, long *, long *);
extern void get_session(char*, char**);
extern void strlower(char *, char *);


/* Globals */

static const char *debug_hdr = "DEBUG-gst_cam_setup.c ";
extern guintptr video_window_handle;


/* Gst Camera setup and start play */

int gst_initialise(CamData *cam_data, MainUiData *m_ui)
{
    GstElement *source, *sink, *convert;
    GstBus *bus;
    GstMessage *msg;
    GstCaps *caps;
    GstElement *filter;
    long width, height;
    int fps;
    char *p;
    char fourcc[5];
    char media[50];
    char s[100];

    /* Create the elements */
    source = gst_element_factory_make ("v4l2src", "source");		// FIX THIS !!!
    sink = gst_element_factory_make ("autovideosink", "sink");
    convert = gst_element_factory_make ("videoconvert", "convert");
    filter = gst_element_factory_make ("capsfilter", "filter");

    /* Create the pipeline */
    cam_data->pipeline = gst_pipeline_new ("cam_video");

    if (!cam_data->pipeline || !source || !sink || !convert || !filter)
    {
	log_msg("CAM0020", NULL, NULL, NULL);
        return FALSE;
    }

    /* Set the device source*/
    g_object_set (source, "device", cam_data->current_dev, NULL);

    /* Build the pipeline - add all the elements */
    gst_bin_add_many (GST_BIN (cam_data->pipeline), source, sink, convert, filter, NULL);

    /* Specify what kind of video is wanted from the camera */
    get_session(CLRFMT, &p);
    strlower(p, fourcc);
    sprintf(media, "video/x-raw,format=(%s)", fourcc);
    get_session(RESOLUTION, &p);
    res_to_long(p, &width, &height);
    get_session(FPS, &p);
    fps = atoi(p);

printf("%s gst_init 6, fps %d, %s\n", debug_hdr, fps, media);
    //caps = gst_caps_new_simple (media,
    caps = gst_caps_new_simple ("video/x-raw",
				"framerate", GST_TYPE_FRACTION, fps, 1,
				"pixel-aspect-ratio", GST_TYPE_FRACTION, 1, 1,
				"width", G_TYPE_INT, width,
				"height", G_TYPE_INT, height,
				NULL);

printf("%s gst_init 7\n", debug_hdr);
    /* Build the pipeline - link all the elements */
    if (gst_element_link_filtered (source, filter, caps) != TRUE)
    {
	sprintf(app_msg_extra, " - source:filter");
	log_msg("CAM0021", NULL, NULL, NULL);
	return FALSE;
    }

    if (gst_element_link_many (filter, convert, sink, NULL) != TRUE)
    {
	sprintf(app_msg_extra, " - filter:convert:sink");
	log_msg("CAM0021", NULL, NULL, NULL);
        return FALSE;
    }

printf("%s gst_init 7a\n", debug_hdr);
    gst_caps_unref(caps);

printf("%s gst_init 8\n", debug_hdr);
    /* Set up sync handler for setting the xid once the pipeline is started */
    bus = gst_pipeline_get_bus (GST_PIPELINE (cam_data->pipeline));
    gst_bus_set_sync_handler (bus, (GstBusSyncHandler) bus_sync_handler, NULL, NULL);
    gst_object_unref (bus);

    if (cam_set_state(cam_data, GST_STATE_PLAYING, NULL) == FALSE)
        return FALSE;

    /* Register a function that GLib will call every second */
    g_timeout_add_seconds (1, (GSourceFunc) refresh_ui, cam_data);

    /* Inforamtion status line */
    sprintf(s, "Camera %s (%s) playing", cam_data->current_cam, cam_data->current_dev);
    gtk_label_set_text (GTK_LABEL (m_ui->status_info), s);

    return TRUE;
}


/* Set pileline state */

int cam_set_state(CamData *cam_data, GstState state, GtkWidget *window)
{
    GstStateChangeReturn ret;
    char s[10];

    ret = gst_element_set_state (cam_data->pipeline, state);

    if (ret == GST_STATE_CHANGE_FAILURE)
    {
    	switch (state)
    	{
	    case GST_STATE_NULL:
	    	strcpy(s, "NULL");
	    	break;

	    case GST_STATE_READY:
	    	strcpy(s, "READY");
	    	break;

	    case GST_STATE_PAUSED:
	    	strcpy(s, "PAUSED");
	    	break;

	    case GST_STATE_PLAYING:
	    	strcpy(s, "PLAYING");
	    	break;

	    default:
	    	strcpy(s, "Unknown");
    	}

	sprintf(app_msg_extra, "Current camera is %s", cam_data->current_cam);
	log_msg("CAM0022", s, "CAM0022", window);
        return FALSE;
    }

    cam_data->state = state;

    return TRUE;
}


/* Callbacks */

static GstBusSyncReply bus_sync_handler (GstBus * bus, GstMessage * message, gpointer user_data)
{
    // ignore anything but 'prepare-window-handle' element messages
    if (!gst_is_video_overlay_prepare_window_handle_message (message))
        return GST_BUS_PASS;

    if (video_window_handle != 0)
    {
        //g_print("%s sync reply\n", debug_hdr);
        GstVideoOverlay *overlay;

        // GST_MESSAGE_SRC (message) will be the video sink element
        overlay = GST_VIDEO_OVERLAY (GST_MESSAGE_SRC (message));
        gst_video_overlay_set_window_handle (overlay, video_window_handle);
    }
    else
    {
        g_warning ("Should have obtained video_window_handle by now!");
    }

    gst_message_unref (message);
    return GST_BUS_DROP;
}


/* This function is called periodically to refresh the GUI */
static gboolean refresh_ui (CamData *cam_data)
{
    GstFormat fmt = GST_FORMAT_TIME;
    gint64 current = -1;

    /* We do not want to update anything unless we are in the PAUSED or PLAYING states */
    if (cam_data->state < GST_STATE_PAUSED)
        return TRUE;

    return TRUE;
}
