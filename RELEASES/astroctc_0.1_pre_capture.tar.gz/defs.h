/*
** Description:	Local standard constant defines
**
** Author:	Anthony Buckley
**
** History
**	06-Dec-2013	Initial
**
*/


/* Includes */


/* General */
#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef _FILE_OFFSET_BITS
#define _FILE_OFFSET_BITS 64
#endif

#if defined (GDK_WINDOWING_X11)
#include <gdk/gdkx.h>
#elif defined (GDK_WINDOWING_WIN32)
#include <gdk/gdkwin32.h>
#elif defined (GDK_WINDOWING_QUARTZ)
#include <gdk/gdkquartz.h>
#endif

#ifndef AC_COLOURS
#define AC_COLOURS
#ifdef MAIN_UI
const GdkRGBA BLUE_GRAY = {.9, .9, 1.0, 1};
const GdkRGBA LIGHT_BLUE = {.5, .5, 1.0, 1.0};
const GdkRGBA MID_BLUE = {.5, .5, 1.0, 1.0};
const GdkRGBA DARK_BLUE = {0, 0, 0.5, 1.0};
const GdkRGBA RED1 = {.8, .1, .1, 1.0};
#else
const GdkRGBA BLUE_GRAY;
extern const GdkRGBA LIGHT_BLUE;
extern const GdkRGBA MID_BLUE;
extern const GdkRGBA DARK_BLUE;
extern const GdkRGBA RED1;
#endif
#endif


/* Application Name */
#ifndef TITLE
#define TITLE "AstroCap"
#endif


/* Camera */
#ifndef CAM_HDR
#include <cam.h>
#endif


/* Video size */
#ifndef _videosz
#define _videosz
#define STD_VWIDTH 640
#define STD_VHEIGHT 480
#endif


/* Interface Names */
#ifndef UI_TITLES
#define UI_TITLES
#define CAM_INFO_UI "Camera Information"
#define VIEW_FILE_UI "File Viewer"
#define USER_PREFS_UI "User Preferences"
#endif


/* Utility globals */
#ifndef ERR_INCLUDED
#define ERR_INCLUDED
#ifdef ERR_FILE
char app_msg_extra[256];
#else
extern char app_msg_extra[256];
#endif
#endif
