/*
** Description:	User Preferences
**
** Author:	Anthony Buckley
**
** History
**	8-Aug-2014	Initial
**
*/


// Structure to contain all user preferences.
// This list is loaded on startup if it exists. If not a default set is created.
// Items are updated on the preferences screen.
// The format of the settings file in the application directory is as follows:-
//	name_key|setting_value		- leading and trailing spaces are ignored
//					- no spaces in key

#ifndef USER_PREFS_H
#define USER_PREFS_H

typedef struct _UserPrefData
{
    char key[10];
    char *val;
} UserPrefData;

// Key values for each session detail stored

#define IMAGE_TYPE "IMAGETYPE"
#define JPEG_QUALITY "JPEGQUAL"
#define CAPTURE_LOCATION "CAPTDIR"
#define FN_ID "FN_ID"
#define FN_TITLE "FN_TITLE"
#define FN_TIMESTAMP "FN_TMSTMP"

#endif
