/*
** Description:	Main program include file
**
** Author:	Anthony Buckley
**
** History
**	08-Sep-2014	Initial
**
*/


/* Defines */

#ifndef MAIN_HDR
#define MAIN_HDR
#endif

/* Structure to contain main interface items for easy access */

typedef struct _main_ui_data
{
    GtkWidget *window;
    GtkWidget *video_window;  
    GtkWidget *status_info;  
    GtkWidget *cbox_dur;
    GtkWidget *cbox_entry_dur;
    GtkWidget *cbox_seq;
    GtkWidget *obj_title;
    GtkWidget *cntl_grid;
    GtkWidget *cbox_clrfmt;
    GtkWidget *cbox_res;
    GtkWidget *cbox_fps;

    int close_handler;
} MainUiData;
