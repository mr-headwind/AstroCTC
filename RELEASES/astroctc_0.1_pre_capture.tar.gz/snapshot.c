/*
** Description: Capture a snapshot from a camera
**
** Author:	Anthony Buckley
**
** History
**	15-Jul-2014	Initial code
**
*/


/* Includes */

#include <gtk/gtk.h>
#include <gst/gst.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <libv4l2.h>
#include <jpeglib.h>
#include <main.h>
#include <cam.h>
#include <preferences.h>
#include <defs.h>
#include <session.h>


/* Defines */


/* Structures and Typedefs required */

struct buffer
{
    void *start;
    size_t length;
};


typedef struct Capture
{
    struct v4l2_format fmt;
    struct v4l2_requestbuffers req;
    struct v4l2_buffer buf;
    struct buffer *buffers;
    unsigned int n_buffers;
    char io_method;
    int n_snaps;
    long width;
    long height;
    int success;
    const gchar *obj_title;
    char *codec;					// Preferences
    unsigned int jpeg_quality;				// Preferences
    char *locn;						// Preferences
    char id;						// Preferences
    char tt;						// Preferences
    char ts;						// Preferences
} capture_t;


/* Prototypes */
int snap_main(CamData *, int, MainUiData *);
int snap_init(CamData *, capture_t *, int, MainUiData *);
static void load_prefs(capture_t *);
int snap_image(CamData *, capture_t *, GtkWidget *);
int streaming_io(CamData *, capture_t *, GtkWidget *);
int mmap_io(CamData *, capture_t *, GtkWidget *);
int usrptr_io(CamData *, capture_t *, GtkWidget *);
int read_io(CamData *, capture_t *, GtkWidget *);
int start_capture(CamData *, capture_t *, GtkWidget *);
int stop_capture(CamData *, GtkWidget *);
int image_capture(CamData *, capture_t *, GtkWidget *);
int image_output(capture_t *, int, char *, GtkWidget *);
void jpeg_file(FILE *, capture_t *);
void bmp_file(FILE *, capture_t *);
void ppm_file(FILE *, capture_t *);
char * bmp_header(capture_t *);
char * dib_header(capture_t *);
unsigned char * img_start_sz(capture_t *, int *);
void img_row(unsigned char *, unsigned char *, int);
void snap_final(CamData *, capture_t *, MainUiData *);
int snap_status(capture_t *, MainUiData *);

extern int cam_set_state(CamData *, GstState);
extern int gst_initialise(CamData *, MainUiData *);
extern int cam_open(char *, int, GtkWidget *);
extern int xioctl(int, int, void *);
extern void log_msg(char*, char*, char*, GtkWidget*);
extern void dttm_stamp(char *, size_t);
extern void get_user_pref(char *, char **);


/* Globals */

static const char *debug_hdr = "DEBUG-snapshot.c ";
static const int hdr_sz = 14;
static const int dib_sz = 40;
unsigned char *bgr_data;


/* Snapshot processing control */

int snap_main(CamData *cam_data, int snap_count, MainUiData *m_ui)
{
    capture_t capt;

    /* Snapshot initial setup */
    if (snap_init(cam_data, &capt, snap_count, m_ui) == FALSE)
    {
    	capt.success = FALSE;
	snap_final(cam_data, &capt, m_ui);
        return FALSE;
    }

    /* Capture an image */
    if (! snap_image(cam_data, &capt, m_ui->window))
    {
    	capt.success = FALSE;
	snap_final(cam_data, &capt, m_ui);
    	return FALSE;
    }

    /* Resume normal viewing */
    snap_final(cam_data, &capt, m_ui);

    return TRUE;
}


/* Close current pipeline, open the device and initialise it for snapshot */

int snap_init(CamData *cam_data, capture_t *capt, int snap_count, MainUiData *m_ui)
{
    char *res_str;
    camera_t *cam;
    struct v4l2_format *fmt;
    char fourcc[5];
    unsigned int min;

    /* Set up */
    if (snap_count <= 0)
    	capt->n_snaps = 1;
    else
	capt->n_snaps = snap_count;

    cam = cam_data->cam;
    fmt = &(capt->fmt);
    capt->success = TRUE;

    /* Preferences */
    load_prefs(capt);

    /* Object title for image file name(s) */
    capt->obj_title = gtk_entry_get_text( GTK_ENTRY (m_ui->obj_title));

    /* Make sure camera is capable of capture */
    if (!(cam->vcaps.capabilities & V4L2_CAP_VIDEO_CAPTURE))
    {
	log_msg("CAM0007", NULL, "CAM0007", m_ui->window);
    	return FALSE;
    }

    if (!(cam->vcaps.capabilities & V4L2_CAP_READWRITE) &&
    	!(cam->vcaps.capabilities & V4L2_CAP_STREAMING))
    {
	log_msg("CAM0007", NULL, "CAM0007", m_ui->window);
    	return FALSE;
    }

    /* Wipe the current pipeline (free all the resources) */
    if (cam_set_state(cam_data, GST_STATE_NULL) == FALSE)
        return FALSE;

    gst_object_unref (cam_data->pipeline);

    /* Open camera */
    cam->fd = v4l2_open(cam->video_dev, O_RDWR | O_NONBLOCK, 0);

    if (cam->fd < 0)
    {
	sprintf(app_msg_extra, "Error: %d, %s", errno, strerror(errno));
	log_msg("CAM0003", cam->video_dev, "SYS9000", m_ui->window);
	return FALSE;
    }

    /* Set format to RGB24 */
    memset(fmt, 0, sizeof(*fmt));

    get_session(RESOLUTION, &res_str);
    res_to_long(res_str, &(capt->width), &(capt->height));

    fmt->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    fmt->fmt.pix.width = capt->width;
    fmt->fmt.pix.height = capt->height;
    fmt->fmt.pix.pixelformat = V4L2_PIX_FMT_RGB24;
    fmt->fmt.pix.field = V4L2_FIELD_INTERLACED;

    if (xioctl(cam->fd, VIDIOC_S_FMT, fmt) == -1)
    {
	sprintf(app_msg_extra, "Error: %d, %s", errno, strerror(errno));
	log_msg("CAM0014", NULL, "CAM0014", m_ui->window);
	return FALSE;
    }

    if (fmt->fmt.pix.pixelformat != V4L2_PIX_FMT_RGB24)
    {
	pxl2fourcc(fmt->fmt.pix.pixelformat, fourcc);
	sprintf(app_msg_extra, "Format is: %s", fourcc);
	log_msg("CAM0017", "Failed to set RGB24 format", "CAM0017", m_ui->window);
	return FALSE;
    }

    if ((fmt->fmt.pix.width != capt->width) || (fmt->fmt.pix.height != capt->height))
    {
	sprintf(app_msg_extra, "Warning: Image dimensions being forced to %d x %d\n",
			       fmt->fmt.pix.width, fmt->fmt.pix.height);
	log_msg("SYS9013", NULL, NULL, NULL);
    }

    /* Buggy driver paranoia */
    min = fmt->fmt.pix.width * 2;

    if (fmt->fmt.pix.bytesperline < min)
	fmt->fmt.pix.bytesperline = min;

    min = fmt->fmt.pix.bytesperline * fmt->fmt.pix.height;

    if (fmt->fmt.pix.sizeimage < min)
	fmt->fmt.pix.sizeimage = min;

    return TRUE;
}


/* Load user preferences for snapshot and filenames */

static void load_prefs(capture_t *capt)
{
    char *p;

    get_user_pref(IMAGE_TYPE, &p);
    capt->codec = p;

    get_user_pref(JPEG_QUALITY, &p);
    capt->jpeg_quality = atoi(p);

    get_user_pref(CAPTURE_LOCATION, &p);
    capt->locn = p;

    get_user_pref(FN_ID, &p);
    capt->id = *p;

    get_user_pref(FN_TITLE, &p);
    capt->tt = *p;

    get_user_pref(FN_TIMESTAMP, &p);
    capt->ts = *p;

    return;
}


/* Release the device buffers, Close off, Rebuild the pipline and restart */

void snap_final(CamData *cam_data, capture_t *capt, MainUiData *m_ui)
{
    int i;

    /* Check early failure */
    if (capt->success == FALSE)
    {
	if (cam_data->pipeline)
	    snap_status(capt, m_ui);

	return;
    }

    /* Clean up */
    if (capt->io_method == 'M')		// Memory mapping
    {
	for(i = 0; i < capt->n_buffers; i++)
	    v4l2_munmap(capt->buffers[i].start, capt->buffers[i].length);

	free(capt->buffers);
    }
    else if (capt->io_method == 'U')	// User pointer
    {
	for(i = 0; i < capt->n_buffers; i++)
	    free(capt->buffers[i].start);

	free(capt->buffers);
    }
    else if (capt->io_method == 'R')	// Read
    {
	free(capt->buffers[0].start);
	free(capt->buffers);
    }

    v4l2_close(cam_data->cam->fd);
    gst_initialise(cam_data, m_ui);
    snap_status(capt, m_ui);

    return;
}


/* Update the status information */

int snap_status(capture_t *capt, MainUiData *m_ui)
{
    if (capt->success == TRUE)
    	gtk_label_set_text (GTK_LABEL (m_ui->status_info), "Snapshot successful");
    else
    	gtk_label_set_text (GTK_LABEL (m_ui->status_info), "Snapshot failed");

    return;
}


/* Take a snapshot */

int snap_image(CamData *cam_data, capture_t *capt, GtkWidget *window)
{
    camera_t *cam;

    cam = cam_data->cam;

    /* Determine the input/output method */
    if (cam->vcaps.capabilities & V4L2_CAP_STREAMING)
    {
    	if (! streaming_io(cam_data, capt, window))
	    return FALSE;

	if (! start_capture(cam_data, capt, window))
	    return FALSE;

	if (! image_capture(cam_data, capt, window))
	    return FALSE;

	if (! stop_capture(cam_data, window))
	    return FALSE;
    }
    else
    {
    	if (! read_io(cam_data, capt, window))
	    return FALSE;

	if (! image_capture(cam_data, capt, window))
	    return FALSE;
    }

    return TRUE;
}


/* Use Memory Map for preference, otherwise User Pointer to request buffers */

int streaming_io(CamData *cam_data, capture_t *capt, GtkWidget *window)
{
    camera_t *cam;

    cam = cam_data->cam;

    /* Try mmap method */
    memset(&(capt->req), 0, sizeof(capt->req));

    capt->req.count = 2;
    capt->req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    capt->req.memory = V4L2_MEMORY_MMAP;

    if (xioctl(cam->fd, VIDIOC_REQBUFS, &(capt->req)) == 0)
    {
    	capt->io_method = 'M';

	if (! mmap_io(cam_data, capt, window))
	    return FALSE;
	else
	    return TRUE;
    }
    
    /* Try user pointer method */
    memset(&(capt->req), 0, sizeof(capt->req));

    capt->req.count = 2;
    capt->req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    capt->req.memory = V4L2_MEMORY_USERPTR;

    if (xioctl(cam->fd, VIDIOC_REQBUFS, &(capt->req)) == 0)
    {
	capt->io_method = 'U';

	if (! usrptr_io(cam_data, capt, window))
	    return FALSE;
	else
	    return TRUE;
    }
    	
    /* Should not get to this point ! */
    sprintf(app_msg_extra,
	    "Camera does not support memory mapping or user pointer IO.\n%s\n",
	    strerror(errno));
    log_msg("CAM0017", "Request buffers", "CAM0017", window);

    return FALSE;
}


/* Memory mapping io */

int mmap_io(CamData *cam_data, capture_t *capt, GtkWidget *window)
{
    camera_t *cam;

    /* Initial */
    if (capt->req.count < 2)
    {
	sprintf(app_msg_extra, "Insufficient buffer memory.\n%s\n", strerror(errno));
	log_msg("CAM0017", "Request buffers", "CAM0017", window);
    	return FALSE;
    }

    cam = cam_data->cam;
    capt->buffers = calloc(capt->req.count, sizeof(*(capt->buffers)));

    /* Query the buffer status and map device memory into app. address space */
    for(capt->n_buffers = 0; capt->n_buffers < capt->req.count; ++capt->n_buffers)
    {
	memset(&(capt->buf), 0, sizeof(capt->buf));

	capt->buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	capt->buf.memory = V4L2_MEMORY_MMAP;
	capt->buf.index = capt->n_buffers;

	if (xioctl(cam->fd, VIDIOC_QUERYBUF, &(capt->buf)) == -1)
	{
	    sprintf(app_msg_extra, "Problem with buffer status: %s\n", strerror(errno));
	    log_msg("CAM0017", "Query buffer status", "CAM0017", window);
	    return FALSE;
	}

	capt->buffers[capt->n_buffers].length = capt->buf.length;
	capt->buffers[capt->n_buffers].start = v4l2_mmap(NULL, capt->buf.length,
							 PROT_READ | PROT_WRITE,
							 MAP_SHARED,
							 cam->fd,
							 capt->buf.m.offset);

	if (MAP_FAILED == capt->buffers[capt->n_buffers].start)
	{
	    sprintf(app_msg_extra, "Problem with memory map: %s\n", strerror(errno));
	    log_msg("CAM0017", "Map device memory", "CAM0017", window);
	    return FALSE;
	}
    }

    return TRUE;
}


/* User Pointer io */

int usrptr_io(CamData *cam_data, capture_t *capt, GtkWidget *window)
{
    camera_t *cam;
    unsigned int page_size;
    unsigned int buffer_size;

    /* Initial */
    if (capt->req.count < 2)
    {
	sprintf(app_msg_extra, "Insufficient buffer memory.\n%s\n", strerror(errno));
	log_msg("CAM0017", "Request buffers", "CAM0017", window);
    	return FALSE;
    }

    cam = cam_data->cam;
    capt->buffers = calloc(capt->req.count, sizeof(*(capt->buffers)));

    page_size = getpagesize();
    buffer_size = (buffer_size + page_size - 1) & ~(page_size - 1);

    /* Align allocate the buffers */
    for(capt->n_buffers = 0; capt->n_buffers < capt->req.count; ++capt->n_buffers)
    {
	capt->buffers[capt->n_buffers].length = buffer_size;
	capt->buffers[capt->n_buffers].start = memalign(page_size, buffer_size);

	if (! capt->buffers[capt->n_buffers].start)
	{
	    sprintf(app_msg_extra, "User pointer memory error: %s\n", strerror(errno));
	    log_msg("CAM0017", "Map device memory", "CAM0017", window);
	    return FALSE;
	}
    }

    return TRUE;
}


/* Read / Write io method */

int read_io(CamData *cam_data, capture_t *capt, GtkWidget *window)
{
    capt->io_method = 'R';
    capt->buffers = calloc(1, sizeof(*(capt->buffers)));

    capt->buffers[0].length = capt->fmt.fmt.pix.sizeimage;
    capt->buffers[0].start = malloc(capt->fmt.fmt.pix.sizeimage);

    if (! capt->buffers[0].start)
    {
	sprintf(app_msg_extra, "Read IO memory error: %s\n", strerror(errno));
	log_msg("CAM0017", "No memory", "CAM0017", window);
	return FALSE;
    }

    return TRUE;
}


/* Start streaming */

int start_capture(CamData *cam_data, capture_t *capt, GtkWidget *window)
{
    unsigned int i;
    camera_t *cam;
    enum v4l2_buf_type type;

    cam = cam_data->cam;

    /* Buffer exchange with driver (enqueue an empty buffer) */
    for(i = 0; i < capt->n_buffers; ++i)
    {
	memset(&(capt->buf), 0, sizeof(capt->buf));

	capt->buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	capt->buf.index = i;

	if (capt->io_method == 'M')
	{
	    capt->buf.memory = V4L2_MEMORY_MMAP;
	}
	else
	{
	    capt->buf.memory = V4L2_MEMORY_USERPTR;
	    capt->buf.m.userptr = (unsigned long) capt->buffers[i].start;
	    capt->buf.length = capt->buffers[i].length;
	}

	if (xioctl(cam->fd, VIDIOC_QBUF, &(capt->buf)) == -1)
	{
	    sprintf(app_msg_extra, "Problem with enqueue: %s\n", strerror(errno));
	    log_msg("CAM0017", "Enqueue a buffer", "CAM0017", window);
	    return FALSE;
	}
    }

    type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    if (xioctl(cam->fd, VIDIOC_STREAMON, &type) == -1)
    {
	sprintf(app_msg_extra, "Problem setting Streaming on: %s\n", strerror(errno));
	log_msg("CAM0017", "Streaming on", "CAM0017", window);
	return FALSE;
    }

    return TRUE;
}


/* Image capture */

int image_capture(CamData *cam_data, capture_t *capt, GtkWidget *window)
{
    camera_t *cam;
    fd_set fds;
    struct timeval tv;
    int i, r;
    char tm_stmp[50];

    /* Allow for a sequence of image captures */
    cam = cam_data->cam;
    dttm_stamp(tm_stmp, sizeof(tm_stmp));

    for(i = 0; i < capt->n_snaps; i++)
    {
	/* Grab a snapshot */
	do
	{
	    FD_ZERO(&fds);
	    FD_SET(cam->fd, &fds);

	    /* Timeout */
	    tv.tv_sec = 2;
	    tv.tv_usec = 0;

	    /* Synchronous I/O */
	    r = select(cam->fd + 1, &fds, NULL, NULL, &tv);
	} while ((r == -1 && (errno = EINTR)));

	if (r == -1)
	{
	    sprintf(app_msg_extra, "Problem with Select: %s\n", strerror(errno));
	    log_msg("CAM0017", "Select sync I/O", "CAM0017", window);
	    return FALSE;
	}

	if (capt->io_method != 'R')
	{
	    /* Buffer exchange with driver (dequeue a filled buffer, then enqueue) */
	    memset(&(capt->buf), 0, sizeof(capt->buf));

	    capt->buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

	    if (capt->io_method == 'M')
		capt->buf.memory = V4L2_MEMORY_MMAP;
	    else
		capt->buf.memory = V4L2_MEMORY_USERPTR;

	    if (xioctl(cam->fd, VIDIOC_DQBUF, &(capt->buf)) == -1)
	    {
		sprintf(app_msg_extra, "Problem with dequeue: %s\n", strerror(errno));
		log_msg("CAM0017", "Dequeue a buffer", "CAM0017", window);
		return FALSE;
	    }

	    /* Write image file */
	    if (! image_output(capt, i, tm_stmp, window))
	    	return FALSE;

	    if (xioctl(cam->fd, VIDIOC_QBUF, &(capt->buf)) == -1)
	    {
		sprintf(app_msg_extra, "Problem with enqueue: %s\n", strerror(errno));
		log_msg("CAM0017", "Enqueue a buffer", "CAM0017", window);
		return FALSE;
	    }
	}
	else if (capt->io_method == 'R')
	{
	    /* Buffer exchange with driver (read from device) */
	    if (v4l2_read(cam->fd, capt->buffers[0].start, capt->buffers[0].length) == -1)
	    {
		sprintf(app_msg_extra, "Problem with device read: %s\n", strerror(errno));
		log_msg("CAM0017", "Read from camera", "CAM0017", window);
		return FALSE;
	    }

	    /* Write image file */
	    if (! image_output(capt, i, tm_stmp, window))
	    	return FALSE;
	}
    }

    return TRUE;
}


/* Stop streaming */

int stop_capture(CamData *cam_data, GtkWidget *window)
{
    enum v4l2_buf_type type;

    type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    if (xioctl(cam_data->cam->fd, VIDIOC_STREAMOFF, &type) == -1)
    {
	sprintf(app_msg_extra, "Problem setting Streaming off: %s\n", strerror(errno));
	log_msg("CAM0017", "Streaming off", "CAM0017", window);
	return FALSE;
    }

    return TRUE;
}


/* Write image output file, doing conversion if necessary */

int image_output(capture_t *capt, int img_id, char *tm_stmp, GtkWidget *window)
{
    char out_name[256];
    char fn[100];
    FILE *fout;

    /* File name */
    get_file_name(fn, img_id, capt->obj_title, tm_stmp, capt->id, capt->tt, capt->ts);
    sprintf(out_name, "%s/%s.%s", capt->locn, fn, capt->codec);

    /* Output */
    fout = fopen(out_name, "w");

    if (! fout)
    {
	sprintf(app_msg_extra, "Cannot open output file: %s\n", strerror(errno));
	log_msg("CAM0017", "Cannot open output file", "CAM0017", window);
	return FALSE;
    }

    /* Write the image file in the user preferred format */
    if (strcmp(capt->codec, "jpg") == 0)
    	jpeg_file(fout, capt);			// Jpeg

    else if (strcmp(capt->codec, "bmp") == 0)
    	bmp_file(fout, capt);			// Bmp 
    else
    	ppm_file(fout, capt);			// Portable

    fclose(fout);

    /* TEST setup if baseline is needed for debug
    sprintf(out_name, "test.ppm");
    fout = fopen(out_name, "w");
    ppm_file(fout, capt);
    fclose(fout);
    */

    return TRUE;
}


/* Write a jpeg image file */

void jpeg_file(FILE *fout, capture_t *capt)
{
    unsigned char* img;
    struct jpeg_compress_struct cinfo;
    struct jpeg_error_mgr jerr;
    JSAMPROW row_pointer[1];

    /* Create jpeg data */
    cinfo.err = jpeg_std_error( &jerr );
    jpeg_create_compress(&cinfo);
    jpeg_stdio_dest(&cinfo, fout);

    /* Set image parameters */
    cinfo.image_width = capt->width;	
    cinfo.image_height = capt->height;
    cinfo.input_components = 3;
    cinfo.in_color_space = JCS_RGB;

    /* Set jpeg compression parameters to default and adjust quality setting */
    jpeg_set_defaults(&cinfo);
    jpeg_set_quality(&cinfo, capt->jpeg_quality, TRUE);

    /* Start compress */
    jpeg_start_compress(&cinfo, TRUE);

    /* Feed data */
    while (cinfo.next_scanline < cinfo.image_height)
    {
	if (capt->io_method == 'M')
	{
	    img = capt->buffers[capt->buf.index].start;
	    row_pointer[0] = &img[cinfo.next_scanline * cinfo.image_width * cinfo.input_components];
	}
	else if (capt->io_method == 'U')
	{
	    img = (void *) capt->buf.m.userptr;
	    row_pointer[0] = &img[cinfo.next_scanline * cinfo.image_width * cinfo.input_components];
	}
	else if (capt->io_method == 'R')
	{
	    img = capt->buffers[0].start;
	    row_pointer[0] = &img[cinfo.next_scanline * cinfo.image_width * cinfo.input_components];
	}					       
	else
	{
	    break;
	}

	jpeg_write_scanlines(&cinfo, row_pointer, 1);
    }

    /* Finish compression */
    jpeg_finish_compress(&cinfo);

    /* Destroy jpeg data */
    jpeg_destroy_compress(&cinfo);

    return;
}


/* Write a portable pixmap file */

void ppm_file(FILE *fout, capture_t *capt)
{
    fprintf(fout, "P6\n%d %d 255\n", capt->fmt.fmt.pix.width, capt->fmt.fmt.pix.height);

    if (capt->io_method != 'R')
	fwrite(capt->buffers[capt->buf.index].start, capt->buf.bytesused, 1, fout);
    else
	fwrite(capt->buffers[0].start, capt->buffers[0].length, 1, fout);

    return;
}


/* Write a bmp image file - Keep it simple as could use netpbm for format conversion */

void bmp_file(FILE *fout, capture_t *capt)
{
    char *bmp_hdr;
    char *dib_hdr;
    unsigned char *bgr_data;
    unsigned char *rgb_data;
    unsigned char *pad;
    int pad_bytes, row_sz;
    int i;
    int img_len;
    const unsigned int c = 0;

    /* Image headers */
    bmp_hdr = bmp_header(capt);
    fwrite(bmp_hdr, hdr_sz, 1, fout);

    dib_hdr = dib_header(capt);
    fwrite(dib_hdr, dib_sz, 1, fout);

    // Each row of data must be a multiple of 4 bytes (24bpp)
    // Padding bytes added to end of each row
    pad_bytes = (4 - (capt->width * 3) % 4) % 4; 

    if (pad_bytes > 0)
    {
	pad = malloc(pad_bytes * sizeof(unsigned char));
	memcpy(pad, &c, pad_bytes);
    }

    /* Image data, row at a time */
    row_sz = (capt->width * 3 * sizeof(unsigned char));
    bgr_data = malloc(sizeof(unsigned char) * row_sz);

    rgb_data = img_start_sz(capt, &img_len);

    for(i = 0; i < capt->height; i++)
    {
	img_row(rgb_data, bgr_data, row_sz);
	fwrite(bgr_data, row_sz, 1, fout);

	if (pad_bytes > 0)
	    fwrite(pad, pad_bytes, 1, fout);

	rgb_data += row_sz;
    }

    /* Clean up */
    free(bmp_hdr);
    free(dib_hdr);
    free(bgr_data);

    if (pad_bytes > 0)
    	free(pad);

    return;
}


/* Build BMP image header */

char * bmp_header(capture_t *capt)
{
    int i;
    char *hdr;

    hdr = malloc(sizeof(char) * hdr_sz);

    /* Windows style first 2 bytes are 'BM' */
    *hdr = 'B';			
    *(hdr + 1) = 'M';

    /* File size (4 bytes) = header size + dib size + (w * h * bpp) */
    i = hdr_sz + dib_sz + (3 * capt->width * capt->height);
    memcpy((hdr + 2), &i, 4);

    /* Set next 4 bytes to 0 */
    i = 0;
    memcpy((hdr + 6), &i, 4);

    /* Image data offset (4 bytes ) */
    i = hdr_sz + dib_sz;
    memcpy((hdr + 10), &i, 4);

    return hdr;
}


/* Build DIB (information header) */

char * dib_header(capture_t *capt)
{
    int i;
    short j;
    char *hdr;

    hdr = malloc(sizeof(char) * dib_sz);

    /* Dib size (4 bytes) */
    memcpy(hdr, &dib_sz, 4);

    /* Bitmap width in pixels (4 bytes) */
    i = (int) capt->width;
    memcpy((hdr + 4), &i, 4);

    /* Bitmap height in pixels (4 bytes), negative indicates top to bottom order */
    i = -((int) capt->height);
    memcpy((hdr + 8), &i, 4);

    /* Single colour plane (2 bytes ) */
    j = 1;
    memcpy((hdr + 12), &j, 2);

    /* Bits per pixel (2 bytes ) */
    j = 24;
    memcpy((hdr + 14), &j, 2);

    /* No compression (4 bytes ) */
    i = 0;
    memcpy((hdr + 16), &i, 4);

    /* Size of raw bitmap data (4 bytes ) */
    i = 0;
    memcpy((hdr + 20), &i, 4);

    /* Pixels per metre - horizontal resolution (4 bytes ) */
    i = 0;
    memcpy((hdr + 24), &i, 4);

    /* Pixels per metre - vertical resolution (4 bytes ) */
    memcpy((hdr + 28), &i, 4);

    /* Number of colours in colour table - not used if >= 16bpp (4 bytes ) */
    memcpy((hdr + 32), &i, 4);

    /* Number of important colours - 0 for every colour (4 bytes ) */
    memcpy((hdr + 36), &i, 4);

    return hdr;
}


/* Return the start of the image and its size */

unsigned char * img_start_sz(capture_t *capt, int *sz)
{
    unsigned char* img;

    if (capt->io_method == 'M')
    {
	img = capt->buffers[capt->buf.index].start;
	*sz = capt->buf.bytesused;
    }
    else if (capt->io_method == 'U')
    {
	img = (void *) capt->buf.m.userptr;
	*sz = capt->buf.bytesused;
    }

    else if (capt->io_method == 'R')
    {
	img = capt->buffers[0].start;
	*sz = capt->buffers[0].length;
    }
    else
    {
    	*sz = 0;
    	return NULL;
    }

    return img;
}


/* Grab a row of image data and swap from rgb to bgr */

void img_row(unsigned char *rgb_data, unsigned char *bgr_data, int row_sz)
{
    int i;

    i = 0;

    while(i < row_sz)
    {
    	*(bgr_data + i) = *(rgb_data + i + 2);
    	*(bgr_data + i + 1) = *(rgb_data + i + 1);
    	*(bgr_data + i + 2) = *(rgb_data + i);

    	i += 3;
    }

    return;
}
