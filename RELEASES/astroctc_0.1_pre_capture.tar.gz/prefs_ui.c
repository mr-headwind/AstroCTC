/*
** Description: Preferences user interface and management.
**
** Author:	Anthony Buckley
**
** History
**	8-Aug-2014	Initial code
**
*/


/* Includes */

#include <gtk/gtk.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <cam.h>
#include <defs.h>
#include <preferences.h>


/* Defines */

#define MAX_PREF 10


/* Types */
typedef struct _prefs_ui_data
{
    GtkWidget *window;
    GtkWidget *pref_cntr;
    GtkWidget *cbox_fmt;
    GtkWidget *jpeg_qual;
    GtkWidget *fn_grid;
    GtkWidget *fn_tmpl;
    GtkWidget *capt_dir;
    int close_handler;
    int fn_err;
} PrefUiData;


/* Prototypes */

int user_prefs_main(GtkWidget *);
int user_prefs_init(GtkWidget *);
PrefUiData * new_pref_ui_data();
void user_prefs_ui(PrefUiData *);
void pref_control(PrefUiData *p_ui);
void image_type(PrefUiData *, PangoFontDescription **, PangoFontDescription **);
void fn_template(PrefUiData *, PangoFontDescription **, PangoFontDescription **);
void file_location(PrefUiData *, PangoFontDescription **, PangoFontDescription **);
void pref_label(char *, PangoFontDescription **, GtkWidget *, int *);
void pref_radio(char *, PangoFontDescription **, GtkWidget *, char, int *);
void set_fn_template(char, char, char, char *, PrefUiData *);
int validate_fn_prefs(char, char, char);
int set_fn_idx(char, int, char [][10]);
int set_fn_val(char);
void set_fn_pref(char *, char *, char *, const gchar *);
void set_fn_handler(PrefUiData *);
void set_tmpl_colour(GtkWidget *, char *);
char find_active_by_parent(GtkWidget *, char);
void get_file_name(char *, int, char *, char *, char, char, char);
void file_name_item(char *, char, char, char, char, int, char *, char *); 
int read_user_prefs(GtkWidget *);
int write_user_prefs(GtkWidget *);
void set_default_prefs();
void set_user_prefs(PrefUiData *);
void get_user_pref(char *, char **);
int set_user_pref(char *, char *);
int pref_save_reqd(PrefUiData *);
int pref_changed(char *, char *);
void free_prefs();
void OnSetFmt(GtkWidget *, gpointer);
void OnFnPref(GtkWidget *, gpointer);
void OnPrefBrowse(GtkWidget*, gpointer);
void OnPrefClose(GtkWidget*, gpointer);
void OnPrefSave(GtkWidget*, gpointer);


extern void log_msg(char*, char*, char*, GtkWidget*);
extern void register_window(GtkWidget *);
extern void deregister_window(GtkWidget *);
extern char * app_dir_path();
extern char * home_dir();
extern GtkWidget * find_widget_by_name(GtkWidget *, char *);
extern void info_dialog(GtkWidget *, char *, char *);
extern gint query_dialog(GtkWidget *, char *, char *);
extern int check_dir(char *);
extern int make_dir(char *);


/* Globals */

static const char *debug_hdr = "DEBUG-prefs_ui.c ";
static int save_indi;
static UserPrefData Preferences[25];
static int pref_count;


/* Display and maintenance of user preferences */

int user_prefs_main(GtkWidget *window)
{
    PrefUiData *ui_data;

    /* Initial */
    if (! user_prefs_init(window))
    	return FALSE;

    ui_data = new_pref_ui_data();

    /* Create the interface */
    user_prefs_ui(ui_data);
    gtk_widget_show_all(ui_data->window);

    /* Register the window */
    register_window(ui_data->window);

    return TRUE;
}


/* Initial checks and values */

int user_prefs_init(GtkWidget *window)
{
    /* Initial */
    save_indi = FALSE;

    /* Should at least be a default set of user preferences */
    if (pref_count == 0)
    {
	log_msg("CAM0008", "No user preferences", "CAM0008", window);
    	return FALSE;
    }

    return TRUE;
}


/* Create new screen data variable */

PrefUiData * new_pref_ui_data()
{
    PrefUiData *ui_data = (PrefUiData *) malloc(sizeof(PrefUiData));
    memset(ui_data, 0, sizeof(PrefUiData));

    return ui_data;
}


/* Create the user interface and set the CallBacks */

void user_prefs_ui(PrefUiData *p_ui)
{
    GtkWidget *save_btn, *close_btn;
    GtkWidget *main_vbox, *btn_box;
    PangoFontDescription *font_desc;

    /* Set up the UI window */
    p_ui->window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(p_ui->window), USER_PREFS_UI);
    gtk_window_set_position(GTK_WINDOW(p_ui->window), GTK_WIN_POS_NONE);
    gtk_window_set_default_size(GTK_WINDOW(p_ui->window), 450, 300);
    gtk_container_set_border_width(GTK_CONTAINER(p_ui->window), 10);
    g_object_set_data (G_OBJECT (p_ui->window), "ui_data", p_ui);

    /* Main view */
    main_vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);

    /* Main update or view grid */
    pref_control(p_ui);

    /* Box container for action buttons */
    btn_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 20);
    gtk_widget_set_halign(GTK_WIDGET (btn_box), GTK_ALIGN_CENTER);

    /* Close button */
    close_btn = gtk_button_new_with_label("  Close  ");
    g_signal_connect_swapped(close_btn, "clicked", G_CALLBACK(OnPrefClose), p_ui->window);
    gtk_box_pack_end (GTK_BOX (btn_box), close_btn, FALSE, FALSE, 0);

    /* Save button */
    save_btn = gtk_button_new_with_label("  Apply  ");
    g_signal_connect(save_btn, "clicked", G_CALLBACK(OnPrefSave), (gpointer) p_ui);
    gtk_box_pack_end (GTK_BOX (btn_box), save_btn, FALSE, FALSE, 0);

    /* Combine everything onto the window */
    gtk_box_pack_start (GTK_BOX (main_vbox), p_ui->pref_cntr, FALSE, FALSE, 0);
    gtk_box_pack_start (GTK_BOX (main_vbox), btn_box, FALSE, FALSE, 0);
    gtk_container_add(GTK_CONTAINER(p_ui->window), main_vbox);

    /* Exit when window closed */
    p_ui->close_handler = g_signal_connect(p_ui->window, "destroy", G_CALLBACK(OnPrefClose), NULL);

    return;
}


/* Control container for user preference adjustments */

void pref_control(PrefUiData *p_ui)
{  
    GtkWidget *label;  
    PangoFontDescription *pf_body, *pf_hdr;
    int row;

    /* Font and layout setup */
    pf_body = pango_font_description_from_string ("Sans 9");
    pf_hdr = pango_font_description_from_string ("Sans 10");

    p_ui->pref_cntr = gtk_box_new(GTK_ORIENTATION_VERTICAL, 2);
    gtk_widget_set_name(p_ui->pref_cntr, "pref_cntr");
    gtk_container_set_border_width (GTK_CONTAINER (p_ui->pref_cntr), 10);

    /* Image type (and optional quality) for snapshots */
    image_type(p_ui, &pf_body, &pf_hdr);

    /* Filename template */
    fn_template(p_ui, &pf_body, &pf_hdr);

    /* Capture and snapshot location */
    file_location(p_ui, &pf_body, &pf_hdr);

    /* Free font */
    pango_font_description_free (pf_body);
    pango_font_description_free (pf_hdr);

    return;
}


/* Image type options */

void image_type(PrefUiData *p_ui,
		PangoFontDescription **pf_body,
		PangoFontDescription **pf_hdr)
{  
    GtkWidget *label;
    GtkWidget *h_box;
    int i, curr_idx;
    char *p;
    char s[50];

    const char *fmts[] = { "jpg", "bmp", "ppm" };
    const int fmt_count = 3;

    /* Heading */
    pango_font_description_set_style(*pf_hdr, PANGO_STYLE_ITALIC);

    label = gtk_label_new("Snapshot");
    gtk_widget_override_color(label, GTK_STATE_FLAG_NORMAL, &DARK_BLUE);
    gtk_widget_override_font (label, *pf_hdr);
    gtk_widget_set_halign(GTK_WIDGET (label), GTK_ALIGN_START);
    gtk_box_pack_start (GTK_BOX (p_ui->pref_cntr), label, FALSE, FALSE, 0);

    pango_font_description_set_style(*pf_hdr, PANGO_STYLE_NORMAL);

    /* Put in horizontal box */
    h_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2);

    /* Label */
    pango_font_description_set_weight(*pf_body, PANGO_WEIGHT_BOLD);

    label = gtk_label_new("Image Type");
    gtk_widget_override_font (label, *pf_body);
    gtk_widget_set_halign(GTK_WIDGET (label), GTK_ALIGN_END);
    gtk_widget_set_margin_left (label, 20);
    gtk_box_pack_start (GTK_BOX (h_box), label, FALSE, FALSE, 0);

    pango_font_description_set_weight(*pf_body, PANGO_WEIGHT_NORMAL);

    /* Combobox */
    p_ui->cbox_fmt = gtk_combo_box_text_new();
    gtk_widget_override_font (p_ui->cbox_fmt, *pf_body);

    /* Add list items, note current value index and set active */
    curr_idx = 0;
    get_user_pref(IMAGE_TYPE, &p);

    for(i = 0; i < fmt_count; i++)
    {
    	sprintf(s, "%d", i);
    	gtk_combo_box_text_append(GTK_COMBO_BOX_TEXT (p_ui->cbox_fmt), s, fmts[i]);

    	if (strcmp(p, fmts[i]) == 0)
	    curr_idx = i;
    }

    gtk_combo_box_set_active(GTK_COMBO_BOX (p_ui->cbox_fmt), curr_idx);
    gtk_box_pack_start (GTK_BOX (h_box), p_ui->cbox_fmt, FALSE, FALSE, 5);
    
    /* Label */
    label = gtk_label_new("Quality");
    pango_font_description_set_weight(*pf_body, PANGO_WEIGHT_BOLD);
    gtk_widget_override_font (label, *pf_body);
    gtk_widget_set_halign(GTK_WIDGET (label), GTK_ALIGN_END);
    gtk_box_pack_start (GTK_BOX (h_box), label, FALSE, FALSE, 0);

    /* Jpeg quality */
    pango_font_description_set_weight(*pf_body, PANGO_WEIGHT_NORMAL);

    p_ui->jpeg_qual = gtk_entry_new();
    gtk_widget_set_name(p_ui->jpeg_qual, "jpeg_qual");
    gtk_widget_override_font (p_ui->jpeg_qual, *pf_body);
    gtk_widget_set_halign(GTK_WIDGET (p_ui->jpeg_qual), GTK_ALIGN_START);
    gtk_entry_set_max_length(GTK_ENTRY (p_ui->jpeg_qual), 4);
    gtk_entry_set_width_chars(GTK_ENTRY (p_ui->jpeg_qual), 4);
    gtk_box_pack_start (GTK_BOX (h_box), p_ui->jpeg_qual, FALSE, FALSE, 3);

    get_user_pref(JPEG_QUALITY, &p);
    gtk_entry_set_text(GTK_ENTRY (p_ui->jpeg_qual), p);

    if (strcmp(p, fmts[0]) == 0)
	gtk_widget_set_sensitive (p_ui->jpeg_qual, FALSE);

    g_signal_connect(p_ui->cbox_fmt, "changed", G_CALLBACK(OnSetFmt), (gpointer) p_ui);

    gtk_box_pack_start (GTK_BOX (p_ui->pref_cntr), h_box, FALSE, FALSE, 0);

    return;
}


/* Timestamp inclusion */

void fn_template(PrefUiData *p_ui,
		 PangoFontDescription **pf_body,
		 PangoFontDescription **pf_hdr)
{  
    GtkWidget *label;
    int row;
    char *p;
    char id, tt, ts;
    char s[30];

    /* Heading */
    pango_font_description_set_style(*pf_hdr, PANGO_STYLE_ITALIC);

    label = gtk_label_new("File Names");
    gtk_widget_override_color(label, GTK_STATE_FLAG_NORMAL, &DARK_BLUE);
    gtk_widget_override_font (label, *pf_hdr);
    gtk_widget_set_halign(GTK_WIDGET (label), GTK_ALIGN_START);
    gtk_widget_set_margin_top (label, 7);
    gtk_box_pack_start (GTK_BOX (p_ui->pref_cntr), label, FALSE, FALSE, 0);

    pango_font_description_set_style(*pf_hdr, PANGO_STYLE_NORMAL);

    /* Place the file name template items in a grid */
    p_ui->fn_grid = gtk_grid_new();
    row = 0;

    /* Sequence No */
    get_user_pref(FN_ID, &p);
    id = *p;
    pref_label("Sequence Id", &(*pf_body), p_ui->fn_grid, &row);
    pref_radio("id", &(*pf_body), p_ui->fn_grid, id, &row);
    row++;

    /* Title */
    get_user_pref(FN_TITLE, &p);
    tt = *p;
    pref_label("Title", &(*pf_body), p_ui->fn_grid, &row);
    pref_radio("tt", &(*pf_body), p_ui->fn_grid, tt, &row);
    row++;

    /* Timestamp */
    get_user_pref(FN_TIMESTAMP, &p);
    ts = *p;
    pref_label("Timestamp", &(*pf_body), p_ui->fn_grid, &row);
    pref_radio("ts", &(*pf_body), p_ui->fn_grid, ts, &row);
    row++;

    /* Connect signal handler for radio buttons */
    set_fn_handler(p_ui);

    /* Mock-up */
    pango_font_description_set_style(*pf_body, PANGO_STYLE_ITALIC);

    set_fn_template(id, tt, ts, s, p_ui);
    p_ui->fn_tmpl = gtk_label_new(s);
    gtk_widget_set_name(p_ui->fn_tmpl, "fn_mockup");
    gtk_widget_override_font (p_ui->fn_tmpl, *pf_body);
    set_tmpl_colour(p_ui->fn_tmpl, s);
    gtk_widget_set_halign(GTK_WIDGET (p_ui->fn_tmpl), GTK_ALIGN_START);
    gtk_grid_attach(GTK_GRID (p_ui->fn_grid), p_ui->fn_tmpl, 1, row, 3, 1);

    /* Add grid to main vbox */
    gtk_box_pack_start (GTK_BOX (p_ui->pref_cntr), p_ui->fn_grid, FALSE, FALSE, 0);

    pango_font_description_set_style(*pf_body, PANGO_STYLE_NORMAL);

    return;
}


/* Capture and Snapshot location directory */

void file_location(PrefUiData *p_ui,
		   PangoFontDescription **pf_body,
		   PangoFontDescription **pf_hdr)
{  
    GtkWidget *label;
    GtkWidget *browse_btn;
    GtkWidget *h_box;
    char *p;

    /* Heading */
    pango_font_description_set_style(*pf_hdr, PANGO_STYLE_ITALIC);

    label = gtk_label_new("Capture Location");
    gtk_widget_override_color(label, GTK_STATE_FLAG_NORMAL, &DARK_BLUE);
    gtk_widget_override_font (label, *pf_hdr);
    gtk_widget_set_halign(GTK_WIDGET (label), GTK_ALIGN_START);
    gtk_widget_set_margin_top (label, 7);
    gtk_box_pack_start (GTK_BOX (p_ui->pref_cntr), label, FALSE, FALSE, 0);

    pango_font_description_set_style(*pf_hdr, PANGO_STYLE_NORMAL);

    /* Put in horizontal box */
    h_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2);

    /* Directory */
    pango_font_description_set_weight(*pf_body, PANGO_WEIGHT_NORMAL);

    p_ui->capt_dir = gtk_entry_new();
    gtk_widget_set_name(p_ui->capt_dir, "capt_dir");
    gtk_widget_override_font (p_ui->capt_dir, *pf_body);
    gtk_widget_set_halign(GTK_WIDGET (p_ui->capt_dir), GTK_ALIGN_START);
    gtk_entry_set_max_length(GTK_ENTRY (p_ui->capt_dir), 256);
    gtk_entry_set_width_chars(GTK_ENTRY (p_ui->capt_dir), 40);
    gtk_box_pack_start (GTK_BOX (h_box), p_ui->capt_dir, FALSE, FALSE, 3);

    get_user_pref(CAPTURE_LOCATION, &p);
    gtk_entry_set_text (GTK_ENTRY (p_ui->capt_dir), p);

    /* Browse button */
    browse_btn = gtk_button_new_with_label("Browse...");
    gtk_widget_override_font (browse_btn, *pf_body);
    g_signal_connect(browse_btn, "clicked", G_CALLBACK(OnPrefBrowse), (gpointer) p_ui);
    gtk_box_pack_start (GTK_BOX (h_box), browse_btn, FALSE, FALSE, 0);

    gtk_box_pack_start (GTK_BOX (p_ui->pref_cntr), h_box, FALSE, FALSE, 0);

    return;
}


/* Create a label */

void pref_label(char *title, PangoFontDescription **pf, GtkWidget *grid, int *row)
{  
    GtkWidget *label;

    pango_font_description_set_weight(*pf, PANGO_WEIGHT_BOLD);

    label = gtk_label_new(title);
    gtk_widget_override_font (label, *pf);
    gtk_widget_set_halign(GTK_WIDGET (label), GTK_ALIGN_END);
    gtk_widget_set_margin_left (label, 20);
    gtk_widget_set_margin_right (label, 10);
    gtk_grid_attach(GTK_GRID (grid), label, 0, *row, 1, 1);

    pango_font_description_set_weight(*pf, PANGO_WEIGHT_NORMAL);

    return;
}


/* Create radio buttons */

void pref_radio(char *nm, PangoFontDescription **pf, GtkWidget *grid, char active, int *row)
{  
    int i;
    char s[10];
    GtkWidget *h_box;
    GtkWidget *radio, *radio_grp;
    const char *rads[] = { "Prefix", "Mid", "Suffix", "None" };
    const int rad_count = 4;

    h_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2);

    for(i = 0; i < rad_count; i++)
    {
    	if (i == 0)
    	{
	    radio = gtk_radio_button_new_with_label (NULL, rads[i]);
	    radio_grp = radio;
	}
    	else
    	{
	    radio = gtk_radio_button_new_with_label_from_widget (GTK_RADIO_BUTTON (radio_grp), rads[i]);
	}

	gtk_widget_override_font (radio, *pf);
	sprintf(s, "%s_%s", nm, rads[i]);
	gtk_widget_set_name(radio, s);

	if (active == rads[i][0])
	    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radio), TRUE);

	gtk_grid_attach(GTK_GRID (grid), radio, i + 1, *row, 1, 1);
    }

    return;
}


/* Set the signal handler for each radio button */

void set_fn_handler(PrefUiData *p_ui)
{
    GtkWidget *radio;

    GList *child_widgets = gtk_container_get_children(GTK_CONTAINER (p_ui->fn_grid));

    child_widgets = g_list_first(child_widgets);

    while (child_widgets != NULL)
    {
	radio = child_widgets->data;

	if (GTK_IS_TOGGLE_BUTTON (radio))
	    g_signal_connect(radio, "toggled", G_CALLBACK(OnFnPref), (gpointer) p_ui);

	child_widgets = g_list_next(child_widgets);
    }

    g_list_free (child_widgets);

    return;
}


/* Derive the sample template filename from the preferences */

void set_fn_template(char id, char tt, char ts, char *tmpl, PrefUiData *p_ui)
{
    int i;
    char s_pref[3][10];
    char s[10];

    /* Validate values */
    p_ui->fn_err = FALSE;

    if (validate_fn_prefs(id, tt, ts) == FALSE)
    {
    	p_ui->fn_err = TRUE;
    	strcpy(tmpl, "capture.type");
    	return;
    }

    /* Fields to empty */
    tmpl[0] = '\0';
    s_pref[0][0] = '\0';
    s_pref[1][0] = '\0';
    s_pref[2][0] = '\0';

    /* Match preference to position */
    i = set_fn_idx(id, 0, s_pref);
    i = set_fn_idx(ts, 2, s_pref);
    i = set_fn_idx(tt, 1, s_pref);

    /* There must be at least a default title in the first available slot */
    if (i == -1)
    {
    	for(i = 0; i < 3; i++)
    	{
	    if (s_pref[i][0] == '\0')
	    {
    		strcpy(s_pref[i], "capture");
    		break;
	    }
    	}
    }

    /* Build up a template */
    for(i = 0; i < 3; i++)
    {
    	if (s_pref[i][0] == '\0')
	    continue;

	if (tmpl[0] != '\0')
	    strcat(tmpl, "_");

	strcat(tmpl, s_pref[i]);
    }

    strcat(tmpl, ".type");

    return;
}


/* Determine position of item in template */

int set_fn_idx(char cc, int trx, char s_pref[][10])
{
    int idx;
    const char *desc[] = {"nn", "title", "timestamp"};

    switch(cc)
    {
	case 'P': idx = 0; break;
	case 'M': idx = 1; break;
	case 'S': idx = 2; break;
	default: idx = -1; break;
    }
     
    if (idx != -1)
    	strcpy(&s_pref[idx][0], desc[trx]);

    return idx;
}


/* Validate filename user preferences */

int validate_fn_prefs(char id, char tt, char ts)
{
    int idn, ttn, tsn;
    int i, val_all;
    const int valid_vals[] = { 0, 4, 16, 20, 64, 68, 80, 84 };

    idn = set_fn_val(id);
    ttn = set_fn_val(tt);
    tsn = set_fn_val(ts);

    val_all = idn + ttn + tsn;

    for(i = 0; i < 8; i++)
    {
    	if (val_all == valid_vals[i])
	    break;
    }

    if (i >= 8)
    	return FALSE;

    return TRUE;
}


/* Set a unique number combination for prefix, middle, suffix and none */

int set_fn_val(char cc)
{
    int val;

    switch(cc)
    {
	case 'P': val = 4; break;
	case 'M': val = 16; break;
	case 'S': val = 64; break;
	default: val = 0; break;
    }

    return val;
}


/* Set the template colour - red = error (capture.type) */

void set_tmpl_colour(GtkWidget *tmpl, char *s)
{
    if (strncmp(s, "capture.", 8) == 0)
	gtk_widget_override_color(tmpl, GTK_STATE_FLAG_NORMAL, &RED1);
    else
	gtk_widget_override_color(tmpl, GTK_STATE_FLAG_NORMAL, &MID_BLUE);

    return;
}


/* Set a preference based on a radio button name */

void set_fn_pref(char *id, char *tt, char *ts, const gchar *nm)
{
    // A bit quirky but the second character tells which preference 
    // and fourth character is the value (P, M, S, N)
    switch(nm[1])
    {
    	case 'd': *id = nm[3]; break; 		// id (Id)
    	case 't': *tt = nm[3]; break; 		// tt (Title)
    	case 's': *ts = nm[3]; break; 		// ts (Timestamp)
    	default: break;
    }

    return;
}


/* Construct a filename */

void get_file_name(char *fn, 
		   int id, char *title, char *tm_stmp, 
		   char idp, char ttp, char tsp)
{
    int len;
    char *s;

    /* Setup */
    *fn = '\0';
    len = strlen(title);
    
    if (len < 8)
    	len = 8;

    s = (char *) malloc(len + 1);

    if (*title == '\0')
	strcpy(s, "capture");
    else
	strcpy(s, title);

    /* Build name */
    file_name_item(fn, 'P', idp, ttp, tsp, id, s, tm_stmp);
    file_name_item(fn, 'M', idp, ttp, tsp, id, s, tm_stmp);
    file_name_item(fn, 'S', idp, ttp, tsp, id, s, tm_stmp);

    /* Fail safe in case all are set to 'N', otherwise remove lazy '_' */
    if (*fn == '\0')
    	strcpy(fn, s);
    else
    	fn[strlen(fn) - 1] = '\0';

    free(s);

    return;
}


/* Set a part of a file name */

void file_name_item(char *fn, char cc, 
		    char idp, char ttp, char tsp,
		    int id, char *title, char *tm_stmp) 
{
    if (idp == cc)
    	sprintf(fn, "%s%03d_", fn, id);

    else if (ttp == cc)
	sprintf(fn, "%s%s_", fn, title);

    else if (tsp == cc)
	sprintf(fn, "%s%s_", fn, tm_stmp);

    return;
}


/* Set a preference based on a radio button name */

char find_active_by_parent(GtkWidget *parent, char pref)
{
    GtkWidget *radio;
    const gchar *widget_name;

    GList *child_widgets = gtk_container_get_children(GTK_CONTAINER (parent));

    child_widgets = g_list_first(child_widgets);

    while (child_widgets != NULL)
    {
	radio = child_widgets->data;

	if (GTK_IS_TOGGLE_BUTTON (radio))
	{
	    widget_name = gtk_widget_get_name (radio);

	    if (widget_name[1] == pref)
	    {
		if (gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (radio)) == TRUE)
		{
		    g_list_free (child_widgets);
		    return widget_name[3];
		}
	    }
	}

	child_widgets = g_list_next(child_widgets);
    }

    g_list_free (child_widgets);

    return '\0';
}


/* Read the user preferences file */

int read_user_prefs(GtkWidget *window)
{
    FILE *fd = NULL;
    struct stat fileStat;
    char buf[256];
    char *pref_fn;
    char *app_dir;
    char *p, *p2;
    int app_dir_len;
    int err;

    /* Initial */
    pref_count = 0;
    memset(Preferences, 0, sizeof(Preferences));

    /* Get the full path for the preferecnes file */
    app_dir = app_dir_path();
    app_dir_len = strlen(app_dir);
    pref_fn = (char *) malloc(app_dir_len + 19);
    sprintf(pref_fn, "%s/user_preferences", app_dir);

    /* If no preferences exist, create a default set */
    err = stat(pref_fn, &fileStat);

    if ((err < 0) || (fileStat.st_size == 0))
    {
	log_msg("SYS9015", NULL, NULL, NULL);
    	set_default_prefs();
	free(pref_fn);

	return TRUE;
    }
    
    /* Read existing user preferences */
    if ((fd = fopen(pref_fn, "r")) == (FILE *) NULL)
    {
	free(pref_fn);
	return FALSE;
    }
    
    /* Store the preferences */
    while ((fgets(buf, sizeof(buf), fd)) != NULL)
    {
	/* Check and save key */
	if ((p = strchr(buf, '|')) == NULL)
	{
	    free(pref_fn);
	    sprintf(app_msg_extra, "%s", buf);
	    log_msg("SYS9014", "Invalid user preference key format", "SYS9014", window);
	    return FALSE;
	}

	if ((p - buf) > (sizeof(Preferences[pref_count].key)) - 1)
	{
	    free(pref_fn);
	    sprintf(app_msg_extra, "%s", buf);
	    log_msg("SYS9014", "Invalid user preference key size", "SYS9014", window);
	    return FALSE;
	}

	strncpy(Preferences[pref_count].key, buf, p - buf);
	string_trim(Preferences[pref_count].key);

	/* Check and save value */
	p++;

	if ((p2 = strchr(p, '\n')) == NULL)
	{
	    free(pref_fn);
	    sprintf(app_msg_extra, "%s", buf);
	    log_msg("SYS9014", "Invalid user preference value", "SYS9014", window);
	    return FALSE;
	}

	*p2 = '\0';
	Preferences[pref_count].val = (char *) malloc(strlen(p) + 1);
	strcpy(Preferences[pref_count].val, p);
	string_trim(Preferences[pref_count].val);
	    
	if (pref_count > MAX_PREF)
	{
	    free(pref_fn);
	    log_msg("SYS9014", "Too many user preferences found", "SYS9014", window);
	    return FALSE;
	}

	pref_count++;
    }

    /* Close off */
    fclose(fd);
    free(pref_fn);
    save_indi = FALSE;

    return TRUE;
}


/* Write the user preferences file */

int write_user_prefs(GtkWidget *window)
{
    FILE *fd = NULL;
    char buf[256];
    char *pref_fn;
    char *app_dir;
    int app_dir_len;
    int i;

    /* Get the full path for the preferecnes file */
    app_dir = app_dir_path();
    app_dir_len = strlen(app_dir);
    pref_fn = (char *) malloc(app_dir_len + 19);
    sprintf(pref_fn, "%s/user_preferences", app_dir);

    /* New or overwrite file */
    if ((fd = fopen(pref_fn, "w")) == (FILE *) NULL)
    {
	free(pref_fn);
	return FALSE;
    }

    /* Write new values */
    for(i = 0; i < pref_count; i++)
    {
    	sprintf(buf, "%s|%s\n", Preferences[i].key, Preferences[i].val);
    	
    	if ((fputs(buf, fd)) == EOF)
    	{
	    free(pref_fn);
	    log_msg("SYS9005", pref_fn, "SYS9005", window);
	    return FALSE;
	}
    }
    
    /* Close off */
    fclose(fd);
    free(pref_fn);
    save_indi = FALSE;

    return TRUE;
}


/* Set up default user preferences */

void set_default_prefs()
{
    char *home_str;
    int len;

    /* Jpeg snapshots */
    strcpy(Preferences[pref_count].key, IMAGE_TYPE);
    Preferences[pref_count].val = (char *) malloc(4);
    strcpy(Preferences[pref_count].val, "jpg");
    pref_count++;

    /* Jpeg quality to 70 */
    strcpy(Preferences[pref_count].key, JPEG_QUALITY);
    Preferences[pref_count].val = (char *) malloc(4);
    strcpy(Preferences[pref_count].val, "70");
    pref_count++;

    /* Captures and snapshots to $HOME/Astrocap_Captures */
    strcpy(Preferences[pref_count].key, CAPTURE_LOCATION);
    home_str = home_dir();
    len = strlen(home_str) + strlen(TITLE) + 11;
    Preferences[pref_count].val = (char *) malloc(len);
    sprintf(Preferences[pref_count].val, "%s/%s_Captures", home_str, TITLE);

    if (! check_dir(Preferences[pref_count].val))
	make_dir(Preferences[pref_count].val);

    pref_count++;

    /* File name template */
    strcpy(Preferences[pref_count].key, FN_ID);
    Preferences[pref_count].val = (char *) malloc(2);
    strcpy(Preferences[pref_count].val, "P");
    pref_count++;

    strcpy(Preferences[pref_count].key, FN_TITLE);
    Preferences[pref_count].val = (char *) malloc(2);
    strcpy(Preferences[pref_count].val, "M");
    pref_count++;

    strcpy(Preferences[pref_count].key, FN_TIMESTAMP);
    Preferences[pref_count].val = (char *) malloc(2);
    strcpy(Preferences[pref_count].val, "S");
    pref_count++;

    /* Save to file */
    write_user_prefs(NULL);

    return;
}


/* Update all user preferences */

void set_user_prefs(PrefUiData *p_ui)
{
    char cc;
    char s[2];
    const gchar *img_type;
    const gchar *jpg_qual;
    const gchar *capt_dir;

    /* Initial */
    s[1] = '\0';

    /* Image type */
    img_type = gtk_combo_box_text_get_active_text (GTK_COMBO_BOX_TEXT (p_ui->cbox_fmt));
    set_user_pref(IMAGE_TYPE, (char *) img_type);

    /* Jpeg quality */
    jpg_qual = gtk_entry_get_text(GTK_ENTRY (p_ui->jpeg_qual));
    set_user_pref(JPEG_QUALITY, (char *) jpg_qual);

    /* File name - ID */
    cc = find_active_by_parent(p_ui->fn_grid, 'd');
    s[0] = cc;
    set_user_pref(FN_ID, s);

    /* File name - Title */
    cc = find_active_by_parent(p_ui->fn_grid, 't');
    s[0] = cc;
    set_user_pref(FN_TITLE, s);

    /* File name - Timestamp */
    cc = find_active_by_parent(p_ui->fn_grid, 's');
    s[0] = cc;
    set_user_pref(FN_TIMESTAMP, s);

    /* File location */
    capt_dir = gtk_entry_get_text(GTK_ENTRY (p_ui->capt_dir));
    set_user_pref(CAPTURE_LOCATION, (char *) capt_dir);

    return;
}


/* Update a user preference */

int set_user_pref(char *key, char *val)
{
    int i;

    /* Find the key entry and set the new value */
    for(i = 0; i < pref_count; i++)
    {
    	if (strcmp(Preferences[i].key, key) == 0)
    	{
	    if (strcmp(key, CAPTURE_LOCATION) == 0)
		Preferences[i].val = realloc(Preferences[i].val, strlen(val) + 1);

	    strcpy(Preferences[i].val, val);
	    break;
    	}
    }

    if (i >= pref_count)
    	return FALSE;

    return TRUE;
}


/* Return a pointer to a user preference value for a key or NULL */

void get_user_pref(char *key, char **val)
{
    int i;

    *val = NULL;

    for(i = 0; i < pref_count; i++)
    {
    	if (strcmp(Preferences[i].key, key) == 0)
    	{
	    *val = Preferences[i].val;
	    break;
    	}
    }

    return;
}


/* Check if changes have been made */

int pref_save_reqd(PrefUiData *p_ui)
{
    gint res;
    char cc;
    char s[2];
    const gchar *img_type;
    const gchar *jpg_qual;
    const gchar *capt_dir;

    /* Initial */
    s[1] = '\0';

    /* File location */
    capt_dir = gtk_entry_get_text(GTK_ENTRY (p_ui->capt_dir));

    /* Capture location exists */
    if (! check_dir((char *) capt_dir))
    {
	res = query_dialog(p_ui->window, "Location (%s) does not exist. Create it?", (char *) capt_dir);

	if (res == GTK_RESPONSE_YES)
	    make_dir((char *) capt_dir);
    }

    if (pref_changed(CAPTURE_LOCATION, (char *) capt_dir))
    	return TRUE;

    /* Image type */
    img_type = gtk_combo_box_text_get_active_text (GTK_COMBO_BOX_TEXT (p_ui->cbox_fmt));

    if (pref_changed(IMAGE_TYPE, (char *) img_type))
    	return TRUE;

    /* Jpeg quality */
    jpg_qual = gtk_entry_get_text(GTK_ENTRY (p_ui->jpeg_qual));

    if (pref_changed(JPEG_QUALITY, (char *) jpg_qual))
    	return TRUE;

    /* File name - ID */
    cc = find_active_by_parent(p_ui->fn_grid, 'd');
    s[0] = cc;
    
    if (pref_changed(FN_ID, s))
    	return TRUE;

    /* File name - Title */
    cc = find_active_by_parent(p_ui->fn_grid, 't');
    s[0] = cc;
    
    if (pref_changed(FN_TITLE, s))
    	return TRUE;

    /* File name - Timestamp */
    cc = find_active_by_parent(p_ui->fn_grid, 's');
    s[0] = cc;
    
    if (pref_changed(FN_TIMESTAMP, s))
    	return TRUE;

    return FALSE;
}


/* Check if changes have been made */

int pref_changed(char *key, char *val)
{
    char *p;

    get_user_pref(key, &p);

    if (strcmp(p, val) != 0)
    	return TRUE;

    return FALSE;
}


/* Free the user preferences */

void free_prefs()
{
    int i;

    for(i = 0; i < pref_count; i++)
    {
    	free(Preferences[pref_count].val);
    }

    return;
}


/* Callback - Set snapshot image type */

void OnSetFmt(GtkWidget *cbox, gpointer user_data)
{  
    gchar *img_type;
    PrefUiData *p_ui;

    /* Get data */
    p_ui = (PrefUiData *) user_data;

    /* None */
    if (gtk_combo_box_get_active (GTK_COMBO_BOX (cbox)) == -1)
    	return;

    /* Enable 'Quality' if Jpeg selected */
    img_type = gtk_combo_box_text_get_active_text (GTK_COMBO_BOX_TEXT (cbox));

    if (strcmp(img_type, "jpg") == 0)
	gtk_widget_set_sensitive (p_ui->jpeg_qual, TRUE);
    else
	gtk_widget_set_sensitive (p_ui->jpeg_qual, FALSE);

    return;
}


/* Callback - Toggle a file name option */

void OnFnPref(GtkWidget *radio, gpointer user_data)
{  
    char id, tt, ts;
    char s[30];
    const gchar *nm;
    GtkWidget *grid;
    PrefUiData *p_ui;
    GtkWidget *fn_tmpl;

    /* Determine which toggle is active */
    if (gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (radio)) == FALSE)
    	return;

    /* Initial */
    id = '\0';
    tt = '\0';
    ts = '\0';
    p_ui = (PrefUiData *) user_data;
    grid = p_ui->fn_grid;

    nm = gtk_widget_get_name (radio);
    set_fn_pref(&id, &tt, &ts, nm);

    /* Get active value for the other preferences */
    if (id == '\0')
    	id = find_active_by_parent(grid, 'd');
    	
    if (tt == '\0')
    	tt = find_active_by_parent(grid, 't');
    	
    if (ts == '\0')
    	ts = find_active_by_parent(grid, 's');

    /* Show new template */
    set_fn_template(id, tt, ts, s, p_ui);
    gtk_label_set_text (GTK_LABEL (p_ui->fn_tmpl), s);
    set_tmpl_colour(p_ui->fn_tmpl, s);

    return;
}


/* Callback - Set capture directory */

void OnPrefBrowse(GtkWidget *browse_btn, gpointer user_data)
{  
    GtkWidget *dialog;
    PrefUiData *p_ui;
    gchar *dir_name;
    gint res;

    /* Get data */
    p_ui = (PrefUiData *) user_data;

    /* Selection */
    dialog = gtk_file_chooser_dialog_new ("Capture Location",
					  GTK_WINDOW (p_ui->window),
					  GTK_FILE_CHOOSER_ACTION_CREATE_FOLDER,
					  "_Cancel", GTK_RESPONSE_CANCEL,
					  "_Apply", GTK_RESPONSE_APPLY,
					  NULL);

    res = gtk_dialog_run (GTK_DIALOG (dialog));

    if (res == GTK_RESPONSE_APPLY)
    {
	GtkFileChooser *chooser = GTK_FILE_CHOOSER (dialog);
	dir_name = gtk_file_chooser_get_filename (chooser);

	if (dir_name)
	{
	    gtk_entry_set_text (GTK_ENTRY (p_ui->capt_dir), dir_name);

	    if (! check_dir(dir_name))
	    {
		res = query_dialog(p_ui->window, "Location (%s) does not exist. Create it?", dir_name);

		if (res == GTK_RESPONSE_YES)
		    make_dir(dir_name);
	    }
	}

	g_free (dir_name);
    }

    gtk_widget_destroy (dialog);

    return;
}


/* Callback for apply changes and close */

void OnPrefSave(GtkWidget *btn, gpointer user_data)
{
    PrefUiData *ui_data;

    /* Get data */
    ui_data = (PrefUiData *) user_data;

    /* Check for changes */
    if ((save_indi = pref_save_reqd(ui_data)) == FALSE)
    {
    	info_dialog(ui_data->window, "There are no changes to save!", "");
    	return;
    }

    /* Error check */
    if (ui_data->fn_err == TRUE)
    {
	log_msg("APP0001", NULL, "APP0001", ui_data->window);
    	return;
    }

    /* Store preferences */
    set_user_prefs(ui_data);

    /* Save to file */
    write_user_prefs(ui_data->window);

    return;
}


// Callback for window close
// Destroy the window and de-register the window 
// Check for changes

void OnPrefClose(GtkWidget *window, gpointer user_data)
{ 
    GtkWidget *dialog;
    PrefUiData *ui_data;
    gint response;

    /* Get data */
    ui_data = (PrefUiData *) g_object_get_data (G_OBJECT (window), "ui_data");

    /* Check for changes */
    if ((save_indi = pref_save_reqd(ui_data)) == TRUE)
    {
	/* Ask if OK to close without saving */
	dialog = gtk_message_dialog_new (GTK_WINDOW (window),
					 GTK_DIALOG_MODAL,
					 GTK_MESSAGE_QUESTION,
					 GTK_BUTTONS_OK_CANCEL,
					 "Close without saving changes?");

	response = gtk_dialog_run (GTK_DIALOG (dialog));
	gtk_widget_destroy (dialog);

	if (response == GTK_RESPONSE_CANCEL)
	    return;
    }

    /* Close the window, free the screen data and block any secondary close signal */
    g_signal_handler_block (window, ui_data->close_handler);

    deregister_window(window);
    gtk_window_close(GTK_WINDOW(window));

    free(ui_data);

    return;
}
