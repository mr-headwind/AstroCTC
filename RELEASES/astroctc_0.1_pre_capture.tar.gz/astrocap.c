/*
** Application:	AstroCap
**
** Author:	Anthony Buckley
**
** Description:
**  	Application control for AstroCap. Allow connecting to a WebCam for capturing
**	video. May be used for anything really, but ostensibly for use in creating astronomical images.
**
** History
**	26-Dec-3013	Initial code
**
** To Do
**	Toolbar icon for Snapshot (?) (main_ui)
**	Centreing widgets (3.12 reqd) (camera_info_ui)
**	Info line not aligning at start
**	Fonts / colours (main_ui)
**	Set Audio Mute for camera - see commented code in OnSetCtrl
**	Check out __u32
**	Stepwise options
**	Known Issue with resolution not expanding as expected
**	drawing area size for different res (related to above)
**	Quick access to session variables ??
**	Snapshot - ability to view (inc thumbnails)
**	Snapshot - read method writes in native format - I think - **** No think its OK
*/


/* Includes */

#include <stdlib.h>  
#include <string.h>  
#include <libgen.h>  
#include <gtk/gtk.h>  
#include <gst/gst.h>
#include <gst/video/videooverlay.h>
#include <main.h>
#include <cam.h>
#include <defs.h>


/* Defines */


/* Prototypes */

void initialise(CamData *);
void final();
GtkWidget* main_ui(CamData *, MainUiData *);

extern int check_app_dir();
extern int reset_log();
extern void read_last_session();
extern void read_user_prefs(GtkWidget *);
extern int save_session();
extern void free_session();
extern void free_prefs();
extern void close_log();
extern void gst_initialise(CamData *, MainUiData *);


/* Globals */

static const char *debug_hdr = "DEBUG-astrocap.c ";
guintptr video_window_handle = 0;


/* Main program control */

int main(int argc, char *argv[])
{  
    GtkWidget *window;  
    CamData cam_data;
    MainUiData m_ui;

    /* Initial work */
    initialise(&cam_data);

    /* Initialise Gtk & GStreamer */
    gtk_init(&argc, &argv);  
    gst_init (&argc, &argv);

    window = main_ui(&cam_data, &m_ui);

    gtk_widget_show_all(window);  

    gst_initialise(&cam_data, &m_ui);

    gtk_main();  

    final();

    exit(0);
}  


/* Initial work */

void initialise(CamData *cam_data)
{
    /* Set variables */
    app_msg_extra[0] = '\0';
    memset(cam_data, 0, sizeof (CamData));

    /* Set application directory */
    if (! check_app_dir())
    	exit(-1);

    /* Reset log file and log start */
    if (! reset_log())
    	exit(-1);

    log_msg("SYS9007", NULL, NULL, NULL);

    /* Load data from the previous session if possible */
    read_last_session();

    /* Load user preferences (a default set if required) */
    read_user_prefs(NULL);

    return;
}


/* Final work */

void final()
{
    /* Save and free the session settings */
    save_session();
    free_session();

    /* Free user preferences */
    free_prefs();

    /* Close log file */
    log_msg("SYS9008", NULL, NULL, NULL);
    close_log();

    return;
}
